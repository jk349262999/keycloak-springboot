/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : localhost:3306
 Source Schema         : keycloak

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 14/12/2020 10:11:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ADMIN_EVENT_ENTITY
-- ----------------------------
DROP TABLE IF EXISTS `ADMIN_EVENT_ENTITY`;
CREATE TABLE `ADMIN_EVENT_ENTITY`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ADMIN_EVENT_TIME` bigint(20) NULL DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `OPERATION_TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTH_REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTH_CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTH_USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `IP_ADDRESS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_PATH` varchar(2550) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REPRESENTATION` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `ERROR` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_TYPE` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ADMIN_EVENT_ENTITY
-- ----------------------------

-- ----------------------------
-- Table structure for ASSOCIATED_POLICY
-- ----------------------------
DROP TABLE IF EXISTS `ASSOCIATED_POLICY`;
CREATE TABLE `ASSOCIATED_POLICY`  (
  `POLICY_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ASSOCIATED_POLICY_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`POLICY_ID`, `ASSOCIATED_POLICY_ID`) USING BTREE,
  INDEX `IDX_ASSOC_POL_ASSOC_POL_ID`(`ASSOCIATED_POLICY_ID`) USING BTREE,
  CONSTRAINT `FK_FRSR5S213XCX4WNKOG82SSRFY` FOREIGN KEY (`ASSOCIATED_POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRPAS14XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ASSOCIATED_POLICY
-- ----------------------------

-- ----------------------------
-- Table structure for AUTHENTICATION_EXECUTION
-- ----------------------------
DROP TABLE IF EXISTS `AUTHENTICATION_EXECUTION`;
CREATE TABLE `AUTHENTICATION_EXECUTION`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTHENTICATOR` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `FLOW_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REQUIREMENT` int(11) NULL DEFAULT NULL,
  `PRIORITY` int(11) NULL DEFAULT NULL,
  `AUTHENTICATOR_FLOW` bit(1) NOT NULL DEFAULT b'0',
  `AUTH_FLOW_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTH_CONFIG` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_AUTH_EXEC_REALM_FLOW`(`REALM_ID`, `FLOW_ID`) USING BTREE,
  INDEX `IDX_AUTH_EXEC_FLOW`(`FLOW_ID`) USING BTREE,
  CONSTRAINT `FK_AUTH_EXEC_FLOW` FOREIGN KEY (`FLOW_ID`) REFERENCES `AUTHENTICATION_FLOW` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_AUTH_EXEC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of AUTHENTICATION_EXECUTION
-- ----------------------------
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('00533a3e-1a49-4251-a754-8018991d7d33', NULL, 'no-cookie-redirect', 'master', '1402a5cd-8bc5-4f73-be86-31a6a7820796', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('07823641-3dab-4bd0-b63c-1df0c0ccec96', NULL, 'idp-create-user-if-unique', 'baeldung', 'f68d98be-f6f1-4d56-8fa9-d6651e7af72e', 2, 10, b'0', NULL, 'f3146035-8d6b-4c15-8981-6779682225d9');
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('0a382908-d295-4ac5-a653-ff8d47fad1f9', NULL, NULL, 'baeldung', '3813102c-4c8b-491f-a5be-ba84a546ec16', 2, 30, b'1', 'c23c2e03-5d4a-43f0-ad11-3e9d6e46d256', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('0b8bf0cf-66a6-4a72-8225-4e76de749495', NULL, NULL, 'baeldung', 'c23c2e03-5d4a-43f0-ad11-3e9d6e46d256', 1, 20, b'1', '96f9440e-25db-4e59-b3bc-3873164f4109', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('0e2b2288-43ca-48f0-8c7f-6e06fd98297f', NULL, NULL, 'baeldung', 'e136f5ee-3125-463c-80d1-0035ea59b35e', 1, 20, b'1', 'bfe22c18-5ebf-4b2b-b47c-62c771e5acdc', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('12504e0a-0ce2-46ce-b6fa-466938081a83', NULL, NULL, 'master', '40cdc59c-96f6-4b49-b0b9-4416eb9690ff', 2, 20, b'1', 'f5c16a72-ae33-4519-87ec-308ac95af86b', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('15d057e0-f04e-488a-885b-cec23ad9f811', NULL, 'conditional-user-configured', 'baeldung', 'f71cf8fa-82b7-4e1d-a9df-45c030523e74', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('15e95fea-dc35-42ee-81bb-e88ef0045597', NULL, 'registration-password-action', 'master', '95a61d46-0793-4aac-9565-990c9226dd70', 0, 50, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('167b0965-50be-4fb8-a264-a32c2a26a355', NULL, 'idp-username-password-form', 'baeldung', 'e136f5ee-3125-463c-80d1-0035ea59b35e', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('1849da05-245d-464e-a668-c21a7214d06a', NULL, 'auth-cookie', 'baeldung', '3813102c-4c8b-491f-a5be-ba84a546ec16', 2, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('18c79547-259a-497a-ad51-41d217d43e41', NULL, 'registration-recaptcha-action', 'master', '95a61d46-0793-4aac-9565-990c9226dd70', 3, 60, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('1b1e2fbb-2a18-4df6-a266-558f58ae04a3', NULL, 'registration-user-creation', 'baeldung', '3eaf98f6-809a-4f13-82f7-3f07b45726ce', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('1da3f141-0d27-48de-8309-5e93969a34f3', NULL, 'basic-auth-otp', 'master', 'bc58268a-6935-4f43-9194-f68a5313b18b', 3, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('1e22da47-1812-4086-bcc3-423d692c7c00', NULL, 'identity-provider-redirector', 'master', 'b3414c84-e337-4c2e-9074-90c7eda4d9eb', 2, 25, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('20a5a6a1-df5c-415c-a18f-237f35464cd2', NULL, 'auth-username-password-form', 'master', '51b9d580-7c5b-4d13-b7e4-e4104249724c', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('21a105a1-740d-4e1f-8feb-c806604a7ac9', NULL, 'auth-spnego', 'master', 'bc58268a-6935-4f43-9194-f68a5313b18b', 3, 30, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('238c3ef9-0ecd-464b-b6aa-a2df609a245e', NULL, NULL, 'baeldung', 'c865136b-d0da-4884-9e7d-0f6d90ab1bdf', 0, 20, b'1', '3be70373-3d54-4f35-b0a7-fb7ead2cd6a8', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('25c6b450-d520-405f-b186-067b760485c9', NULL, NULL, 'master', '07ec271f-f933-4326-91b1-210e08b8bb34', 1, 40, b'1', '85876b61-0f93-4ac4-99b2-2b18de0e2eb5', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('2722e4ee-927b-490d-a201-a982d25dbb91', NULL, NULL, 'baeldung', 'f68d98be-f6f1-4d56-8fa9-d6651e7af72e', 2, 20, b'1', 'c865136b-d0da-4884-9e7d-0f6d90ab1bdf', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('275c399b-63f2-41bd-9250-2318bbe63e3f', NULL, 'registration-user-creation', 'master', '95a61d46-0793-4aac-9565-990c9226dd70', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('27da0ed5-cc36-45b7-b4d0-bfaba3e546f0', NULL, 'client-jwt', 'master', '9173f301-5ebe-46bb-a98e-a2c46c254b83', 2, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('2817dec1-e506-4cf5-87e4-cc28630e60a6', NULL, 'client-secret-jwt', 'baeldung', 'bbb11fa8-da51-4946-9f7d-853f56abba2a', 2, 30, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('29a74928-2dec-4d2a-8866-075b70501720', NULL, NULL, 'master', '4db08c41-0c79-4fcc-9e81-2ba529261ad3', 0, 20, b'1', '9f848516-e1b3-465c-95d0-235c5f88861f', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('2bda47ca-60c3-4e50-9cc4-b0dcf46ae1df', NULL, 'registration-profile-action', 'baeldung', '3eaf98f6-809a-4f13-82f7-3f07b45726ce', 0, 40, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('2eb4968f-fbb3-43d7-8008-52c84973cc89', NULL, NULL, 'master', '6164789f-eab7-466c-ac16-c6647cc93b39', 1, 30, b'1', 'ae5b574c-ecbe-47be-b3bb-d5534f390110', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('3382e390-8c88-4b74-a2e9-d4ab6b22b3d3', NULL, 'conditional-user-configured', 'baeldung', '96f9440e-25db-4e59-b3bc-3873164f4109', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('39406363-7913-4145-8311-3b7108ccb9a7', NULL, 'idp-create-user-if-unique', 'master', '9f848516-e1b3-465c-95d0-235c5f88861f', 2, 10, b'0', NULL, '527ed77e-b867-44e5-a492-06d9bcb68869');
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('3ace1847-4b77-46d8-a83f-6463868c9c77', NULL, 'basic-auth-otp', 'baeldung', '63e109c3-876b-46c7-8ea2-d3473e4f5940', 3, 30, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('3ea90467-e915-4329-9568-caf8a00502f5', NULL, 'direct-grant-validate-otp', 'baeldung', 'f71cf8fa-82b7-4e1d-a9df-45c030523e74', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('43c0ada6-b18f-48b6-85a5-a6b4a2798a70', NULL, 'auth-cookie', 'master', 'b3414c84-e337-4c2e-9074-90c7eda4d9eb', 2, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('4db1e3c6-b1dc-490d-aa7a-ac2e6df88ee6', NULL, NULL, 'baeldung', 'bdd3e09a-6ea7-46ba-b6be-1f4b54b3a212', 1, 40, b'1', 'edcecfaf-9180-41d8-bacf-b59e85b35141', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('511675b4-eb69-4436-bbf9-0a6acc8f0bb6', NULL, 'auth-otp-form', 'master', '65c242ff-1618-4106-9de1-eff170e5730e', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('528e3666-779a-425e-aaa2-e2dc554b361a', NULL, NULL, 'master', '51b9d580-7c5b-4d13-b7e4-e4104249724c', 1, 20, b'1', '91f8d70b-ad09-44ff-b746-9574dc1ddbe0', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('550e9921-12bf-4449-b404-6433fc1e40ae', NULL, 'client-x509', 'baeldung', 'bbb11fa8-da51-4946-9f7d-853f56abba2a', 2, 40, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('5599274a-127d-4a99-bdc3-3d79fd29e1db', NULL, NULL, 'master', '9f848516-e1b3-465c-95d0-235c5f88861f', 2, 20, b'1', 'c36d4b16-47d9-441b-8e54-5d9eff0363a9', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('575f1eb7-8b87-4548-8092-2587d5f64495', NULL, NULL, 'master', 'c36d4b16-47d9-441b-8e54-5d9eff0363a9', 0, 20, b'1', '40cdc59c-96f6-4b49-b0b9-4416eb9690ff', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('57f3a54a-33fb-4eb7-bdfa-213e810bb6b0', NULL, 'auth-otp-form', 'baeldung', '96f9440e-25db-4e59-b3bc-3873164f4109', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('609f33ed-c680-4f6a-adba-06f8e944fb18', NULL, 'reset-password', 'baeldung', 'bdd3e09a-6ea7-46ba-b6be-1f4b54b3a212', 0, 30, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('61c53ad1-9007-4e3f-9ebb-70ba6cdc6e21', NULL, 'auth-otp-form', 'master', '91f8d70b-ad09-44ff-b746-9574dc1ddbe0', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6583c336-e399-4f80-8980-301a2f5fe493', NULL, 'client-secret', 'master', '9173f301-5ebe-46bb-a98e-a2c46c254b83', 2, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('659d9f07-1f41-48a3-985a-f7ec57a087ec', NULL, 'direct-grant-validate-password', 'master', '6164789f-eab7-466c-ac16-c6647cc93b39', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('683734f4-90e4-4cac-af16-2adcc0aacfe3', NULL, 'reset-credential-email', 'master', '07ec271f-f933-4326-91b1-210e08b8bb34', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6a38281f-bfb6-4e21-bfb0-2666a6f95a7e', NULL, 'client-x509', 'master', '9173f301-5ebe-46bb-a98e-a2c46c254b83', 2, 40, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6ae826a9-3192-4f8b-bb8e-ea83e6cd0425', NULL, 'reset-password', 'master', '07ec271f-f933-4326-91b1-210e08b8bb34', 0, 30, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6b1dd6f1-bc23-451b-a670-617f34229852', NULL, 'conditional-user-configured', 'baeldung', 'bfe22c18-5ebf-4b2b-b47c-62c771e5acdc', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6c309f12-5818-407d-a64c-a02ef64c4608', NULL, 'idp-username-password-form', 'master', 'f5c16a72-ae33-4519-87ec-308ac95af86b', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6e9134e1-f86c-4ce3-8a3d-e39111a5cda8', NULL, NULL, 'baeldung', '2d485fd1-d9d4-4663-b2e0-ba3fb853c1f9', 1, 30, b'1', 'f71cf8fa-82b7-4e1d-a9df-45c030523e74', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('6f5099c9-5684-498d-a823-f1ce1557e8f2', NULL, 'reset-otp', 'master', '85876b61-0f93-4ac4-99b2-2b18de0e2eb5', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('721465b7-0c16-4b63-af63-d8d9cfee1665', NULL, 'basic-auth', 'baeldung', '63e109c3-876b-46c7-8ea2-d3473e4f5940', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('735d2d39-353b-469d-b8d8-d1bb47ea90dd', NULL, 'idp-review-profile', 'baeldung', 'f6502db3-6e3c-41e9-b190-25c0453d1973', 0, 10, b'0', NULL, '4c555807-8220-4d9a-b4b4-ad4fa4d470ab');
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('7d13126e-ccce-4ea4-afb6-dc0feba97e0b', NULL, 'auth-username-password-form', 'baeldung', 'c23c2e03-5d4a-43f0-ad11-3e9d6e46d256', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('86cec393-5aaf-4d56-8df8-4f82701c6027', NULL, 'reset-credential-email', 'baeldung', 'bdd3e09a-6ea7-46ba-b6be-1f4b54b3a212', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('8aaac7a4-125a-4388-a072-22fd8eefca00', NULL, NULL, 'master', 'b3414c84-e337-4c2e-9074-90c7eda4d9eb', 2, 30, b'1', '51b9d580-7c5b-4d13-b7e4-e4104249724c', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('9202f55a-d889-4b19-ba3f-fd50a4d80748', NULL, NULL, 'baeldung', '3be70373-3d54-4f35-b0a7-fb7ead2cd6a8', 2, 20, b'1', 'e136f5ee-3125-463c-80d1-0035ea59b35e', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('9280e2b7-99af-439c-b83e-31539a697495', NULL, 'direct-grant-validate-otp', 'master', 'ae5b574c-ecbe-47be-b3bb-d5534f390110', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('9983cd14-9924-47da-b75b-8febf67f7cba', NULL, 'idp-confirm-link', 'master', 'c36d4b16-47d9-441b-8e54-5d9eff0363a9', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('99de6162-f931-47ec-83ec-743b466154c6', NULL, 'docker-http-basic-authenticator', 'baeldung', '03120017-9f11-406e-a0a9-835b476c161a', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('a06b1e86-5b42-41fc-b301-df4791e1cf92', NULL, 'docker-http-basic-authenticator', 'master', 'aa7f7f22-29b9-4dcf-ae1b-be2c65f2d482', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('a1a84ec5-91d8-49ac-855a-725a82b9dfb2', NULL, 'auth-spnego', 'baeldung', '63e109c3-876b-46c7-8ea2-d3473e4f5940', 3, 40, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('a6ae3fc9-3654-48ba-9940-4a82ef9d736c', NULL, 'basic-auth', 'master', 'bc58268a-6935-4f43-9194-f68a5313b18b', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('a6e77a6d-79f4-4bd6-aab5-011e03baa0e8', NULL, 'registration-profile-action', 'master', '95a61d46-0793-4aac-9565-990c9226dd70', 0, 40, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('a937a4a9-feaf-4969-be2a-75fee6cbae83', NULL, 'conditional-user-configured', 'master', '65c242ff-1618-4106-9de1-eff170e5730e', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('ad92891f-1b5c-460b-9496-24d9f5b8aedb', NULL, 'http-basic-authenticator', 'baeldung', '1b6e2200-ceeb-485d-8d5f-8796fefb54d2', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('b38b19a9-022b-479f-802e-3cc4e4c6cab3', NULL, 'reset-otp', 'baeldung', 'edcecfaf-9180-41d8-bacf-b59e85b35141', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('b6d82756-dae4-497b-8271-4dd2f728d89d', NULL, 'direct-grant-validate-password', 'baeldung', '2d485fd1-d9d4-4663-b2e0-ba3fb853c1f9', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('be661eea-a06d-4f9c-8d7d-0e69dd2532ae', NULL, 'client-jwt', 'baeldung', 'bbb11fa8-da51-4946-9f7d-853f56abba2a', 2, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('bf884f31-feaf-4f1f-a7aa-8f028817734b', NULL, 'http-basic-authenticator', 'master', 'd37e6ced-1b76-4276-8e84-1d3335d158b3', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('bfa4079d-846f-434a-afa6-6bfe301fdf64', NULL, 'client-secret-jwt', 'master', '9173f301-5ebe-46bb-a98e-a2c46c254b83', 2, 30, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('c49dcd3c-26a3-4ab8-8e49-1e2306e10b23', NULL, 'registration-password-action', 'baeldung', '3eaf98f6-809a-4f13-82f7-3f07b45726ce', 0, 50, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('c567b5f8-e5cc-4d26-b041-8d5511ee5774', NULL, 'registration-recaptcha-action', 'baeldung', '3eaf98f6-809a-4f13-82f7-3f07b45726ce', 3, 60, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('c8c0ceec-1de2-4253-9002-97e3047cb243', NULL, 'direct-grant-validate-username', 'master', '6164789f-eab7-466c-ac16-c6647cc93b39', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('cce8f559-8bbf-48c5-87bf-63ac32f3d379', NULL, NULL, 'master', 'f5c16a72-ae33-4519-87ec-308ac95af86b', 1, 20, b'1', '65c242ff-1618-4106-9de1-eff170e5730e', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('cf3250a7-8c24-478a-90e9-014266bb4a97', NULL, 'reset-credentials-choose-user', 'baeldung', 'bdd3e09a-6ea7-46ba-b6be-1f4b54b3a212', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('d099b488-2458-4d52-b150-28657ce86123', NULL, NULL, 'baeldung', 'f6502db3-6e3c-41e9-b190-25c0453d1973', 0, 20, b'1', 'f68d98be-f6f1-4d56-8fa9-d6651e7af72e', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('d3ff4d8a-2cd1-4b1a-889b-ce7bf7bfa717', NULL, 'direct-grant-validate-username', 'baeldung', '2d485fd1-d9d4-4663-b2e0-ba3fb853c1f9', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('d5cd0c80-d28c-44fc-9f4f-3eebf8f09794', NULL, 'conditional-user-configured', 'master', '91f8d70b-ad09-44ff-b746-9574dc1ddbe0', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('d6f4a9ad-058c-47f7-8a2f-638ab1dbe4b3', NULL, 'auth-spnego', 'baeldung', '3813102c-4c8b-491f-a5be-ba84a546ec16', 3, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('db2dcea3-8656-40ab-9455-1a0704105334', NULL, 'no-cookie-redirect', 'baeldung', '63e109c3-876b-46c7-8ea2-d3473e4f5940', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('dcc184db-df5d-447e-be7c-b43ef58260ad', NULL, 'conditional-user-configured', 'master', 'ae5b574c-ecbe-47be-b3bb-d5534f390110', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('de46989f-f6ac-4376-86f8-b644478bc231', NULL, 'idp-review-profile', 'master', '4db08c41-0c79-4fcc-9e81-2ba529261ad3', 0, 10, b'0', NULL, '6b99cb35-1c79-4a94-821b-9d4e3eb07ddc');
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('e1b0f0e6-2ee7-42f1-a137-4983e0a47506', NULL, 'idp-confirm-link', 'baeldung', 'c865136b-d0da-4884-9e7d-0f6d90ab1bdf', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('e3a5cbba-bbf7-4ad0-bb6e-55cc62df82c3', NULL, 'reset-credentials-choose-user', 'master', '07ec271f-f933-4326-91b1-210e08b8bb34', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('e727fcc9-5b31-4df7-89b4-d84b6b664861', NULL, 'conditional-user-configured', 'baeldung', 'edcecfaf-9180-41d8-bacf-b59e85b35141', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('e766c8f9-25d2-4bec-ae18-18040f69fbd8', NULL, 'registration-page-form', 'master', '5a8cbb8b-aeaf-4ca2-802a-daf5fe6f23a9', 0, 10, b'1', '95a61d46-0793-4aac-9565-990c9226dd70', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('ed354208-4271-4a97-8bb0-21b53ff81b62', NULL, NULL, 'master', '1402a5cd-8bc5-4f73-be86-31a6a7820796', 0, 20, b'1', 'bc58268a-6935-4f43-9194-f68a5313b18b', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('f0a4c6c2-f147-48b7-99c2-d4e48a51ef8c', NULL, 'registration-page-form', 'baeldung', '4dac5729-d980-458f-8b50-9662c475f229', 0, 10, b'1', '3eaf98f6-809a-4f13-82f7-3f07b45726ce', NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('f1fef395-c28b-4480-82d2-612dcba3e69a', NULL, 'client-secret', 'baeldung', 'bbb11fa8-da51-4946-9f7d-853f56abba2a', 2, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('f215308c-b29c-41ba-afd2-ca99f1ffd4bb', NULL, 'conditional-user-configured', 'master', '85876b61-0f93-4ac4-99b2-2b18de0e2eb5', 0, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('f5c217ad-4de0-4281-98c9-253f52a0d452', NULL, 'idp-email-verification', 'master', '40cdc59c-96f6-4b49-b0b9-4416eb9690ff', 2, 10, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('f6998a17-31ed-4e41-bdf8-aab1a5320772', NULL, 'identity-provider-redirector', 'baeldung', '3813102c-4c8b-491f-a5be-ba84a546ec16', 2, 25, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('f95026c9-dfb6-412c-99c7-ebcd72e68b09', NULL, 'auth-otp-form', 'baeldung', 'bfe22c18-5ebf-4b2b-b47c-62c771e5acdc', 0, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('fcca241b-97c9-492e-a1b1-e68c88196b64', NULL, 'auth-spnego', 'master', 'b3414c84-e337-4c2e-9074-90c7eda4d9eb', 3, 20, b'0', NULL, NULL);
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('fd3d908c-ab70-41db-afa3-04d9ae20cbcb', NULL, 'idp-email-verification', 'baeldung', '3be70373-3d54-4f35-b0a7-fb7ead2cd6a8', 2, 10, b'0', NULL, NULL);

-- ----------------------------
-- Table structure for AUTHENTICATION_FLOW
-- ----------------------------
DROP TABLE IF EXISTS `AUTHENTICATION_FLOW`;
CREATE TABLE `AUTHENTICATION_FLOW`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'basic-flow',
  `TOP_LEVEL` bit(1) NOT NULL DEFAULT b'0',
  `BUILT_IN` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_AUTH_FLOW_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_AUTH_FLOW_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of AUTHENTICATION_FLOW
-- ----------------------------
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('03120017-9f11-406e-a0a9-835b476c161a', 'docker auth', 'Used by Docker clients to authenticate against the IDP', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('07ec271f-f933-4326-91b1-210e08b8bb34', 'reset credentials', 'Reset credentials for a user if they forgot their password or something', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('1402a5cd-8bc5-4f73-be86-31a6a7820796', 'http challenge', 'An authentication flow based on challenge-response HTTP Authentication Schemes', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('1b6e2200-ceeb-485d-8d5f-8796fefb54d2', 'saml ecp', 'SAML ECP Profile Authentication Flow', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('2d485fd1-d9d4-4663-b2e0-ba3fb853c1f9', 'direct grant', 'OpenID Connect Resource Owner Grant', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('3813102c-4c8b-491f-a5be-ba84a546ec16', 'browser', 'browser based authentication', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('3be70373-3d54-4f35-b0a7-fb7ead2cd6a8', 'Handle Existing Account - Alternatives - 0', 'Subflow of Handle Existing Account with alternative executions', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('3eaf98f6-809a-4f13-82f7-3f07b45726ce', 'registration form', 'registration form', 'baeldung', 'form-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('40cdc59c-96f6-4b49-b0b9-4416eb9690ff', 'Account verification options', 'Method with which to verity the existing account', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('4dac5729-d980-458f-8b50-9662c475f229', 'registration', 'registration flow', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('4db08c41-0c79-4fcc-9e81-2ba529261ad3', 'first broker login', 'Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('51b9d580-7c5b-4d13-b7e4-e4104249724c', 'forms', 'Username, password, otp and other auth forms.', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('5a8cbb8b-aeaf-4ca2-802a-daf5fe6f23a9', 'registration', 'registration flow', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('6164789f-eab7-466c-ac16-c6647cc93b39', 'direct grant', 'OpenID Connect Resource Owner Grant', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('63e109c3-876b-46c7-8ea2-d3473e4f5940', 'http challenge', 'An authentication flow based on challenge-response HTTP Authentication Schemes', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('65c242ff-1618-4106-9de1-eff170e5730e', 'First broker login - Conditional OTP', 'Flow to determine if the OTP is required for the authentication', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('85876b61-0f93-4ac4-99b2-2b18de0e2eb5', 'Reset - Conditional OTP', 'Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('9173f301-5ebe-46bb-a98e-a2c46c254b83', 'clients', 'Base authentication for clients', 'master', 'client-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('91f8d70b-ad09-44ff-b746-9574dc1ddbe0', 'Browser - Conditional OTP', 'Flow to determine if the OTP is required for the authentication', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('95a61d46-0793-4aac-9565-990c9226dd70', 'registration form', 'registration form', 'master', 'form-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('96f9440e-25db-4e59-b3bc-3873164f4109', 'forms - auth-otp-form - Conditional', 'Flow to determine if the auth-otp-form authenticator should be used or not.', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('9f848516-e1b3-465c-95d0-235c5f88861f', 'User creation or linking', 'Flow for the existing/non-existing user alternatives', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('aa7f7f22-29b9-4dcf-ae1b-be2c65f2d482', 'docker auth', 'Used by Docker clients to authenticate against the IDP', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('ae5b574c-ecbe-47be-b3bb-d5534f390110', 'Direct Grant - Conditional OTP', 'Flow to determine if the OTP is required for the authentication', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('b3414c84-e337-4c2e-9074-90c7eda4d9eb', 'browser', 'browser based authentication', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('bbb11fa8-da51-4946-9f7d-853f56abba2a', 'clients', 'Base authentication for clients', 'baeldung', 'client-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('bc58268a-6935-4f43-9194-f68a5313b18b', 'Authentication Options', 'Authentication options.', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('bdd3e09a-6ea7-46ba-b6be-1f4b54b3a212', 'reset credentials', 'Reset credentials for a user if they forgot their password or something', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('bfe22c18-5ebf-4b2b-b47c-62c771e5acdc', 'Verify Existing Account by Re-authentication - auth-otp-form - Conditional', 'Flow to determine if the auth-otp-form authenticator should be used or not.', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('c23c2e03-5d4a-43f0-ad11-3e9d6e46d256', 'forms', 'Username, password, otp and other auth forms.', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('c36d4b16-47d9-441b-8e54-5d9eff0363a9', 'Handle Existing Account', 'Handle what to do if there is existing account with same email/username like authenticated identity provider', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('c865136b-d0da-4884-9e7d-0f6d90ab1bdf', 'Handle Existing Account', 'Handle what to do if there is existing account with same email/username like authenticated identity provider', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('d37e6ced-1b76-4276-8e84-1d3335d158b3', 'saml ecp', 'SAML ECP Profile Authentication Flow', 'master', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('e136f5ee-3125-463c-80d1-0035ea59b35e', 'Verify Existing Account by Re-authentication', 'Reauthentication of existing account', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('edcecfaf-9180-41d8-bacf-b59e85b35141', 'reset credentials - reset-otp - Conditional', 'Flow to determine if the reset-otp authenticator should be used or not.', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('f5c16a72-ae33-4519-87ec-308ac95af86b', 'Verify Existing Account by Re-authentication', 'Reauthentication of existing account', 'master', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('f6502db3-6e3c-41e9-b190-25c0453d1973', 'first broker login', 'Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account', 'baeldung', 'basic-flow', b'1', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('f68d98be-f6f1-4d56-8fa9-d6651e7af72e', 'first broker login - Alternatives - 0', 'Subflow of first broker login with alternative executions', 'baeldung', 'basic-flow', b'0', b'1');
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('f71cf8fa-82b7-4e1d-a9df-45c030523e74', 'direct grant - direct-grant-validate-otp - Conditional', 'Flow to determine if the direct-grant-validate-otp authenticator should be used or not.', 'baeldung', 'basic-flow', b'0', b'1');

-- ----------------------------
-- Table structure for AUTHENTICATOR_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG`;
CREATE TABLE `AUTHENTICATOR_CONFIG`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_AUTH_CONFIG_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_AUTH_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of AUTHENTICATOR_CONFIG
-- ----------------------------
INSERT INTO `AUTHENTICATOR_CONFIG` VALUES ('4c555807-8220-4d9a-b4b4-ad4fa4d470ab', 'review profile config', 'baeldung');
INSERT INTO `AUTHENTICATOR_CONFIG` VALUES ('527ed77e-b867-44e5-a492-06d9bcb68869', 'create unique user config', 'master');
INSERT INTO `AUTHENTICATOR_CONFIG` VALUES ('6b99cb35-1c79-4a94-821b-9d4e3eb07ddc', 'review profile config', 'master');
INSERT INTO `AUTHENTICATOR_CONFIG` VALUES ('f3146035-8d6b-4c15-8981-6779682225d9', 'create unique user config', 'baeldung');

-- ----------------------------
-- Table structure for AUTHENTICATOR_CONFIG_ENTRY
-- ----------------------------
DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG_ENTRY`;
CREATE TABLE `AUTHENTICATOR_CONFIG_ENTRY`  (
  `AUTHENTICATOR_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`AUTHENTICATOR_ID`, `NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of AUTHENTICATOR_CONFIG_ENTRY
-- ----------------------------
INSERT INTO `AUTHENTICATOR_CONFIG_ENTRY` VALUES ('4c555807-8220-4d9a-b4b4-ad4fa4d470ab', 'missing', 'update.profile.on.first.login');
INSERT INTO `AUTHENTICATOR_CONFIG_ENTRY` VALUES ('527ed77e-b867-44e5-a492-06d9bcb68869', 'false', 'require.password.update.after.registration');
INSERT INTO `AUTHENTICATOR_CONFIG_ENTRY` VALUES ('6b99cb35-1c79-4a94-821b-9d4e3eb07ddc', 'missing', 'update.profile.on.first.login');
INSERT INTO `AUTHENTICATOR_CONFIG_ENTRY` VALUES ('f3146035-8d6b-4c15-8981-6779682225d9', 'false', 'require.password.update.after.registration');

-- ----------------------------
-- Table structure for BROKER_LINK
-- ----------------------------
DROP TABLE IF EXISTS `BROKER_LINK`;
CREATE TABLE `BROKER_LINK`  (
  `IDENTITY_PROVIDER` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `BROKER_USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `BROKER_USERNAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `TOKEN` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`, `USER_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of BROKER_LINK
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT`;
CREATE TABLE `CLIENT`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `FULL_SCOPE_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NOT_BEFORE` int(11) NULL DEFAULT NULL,
  `PUBLIC_CLIENT` bit(1) NOT NULL DEFAULT b'0',
  `SECRET` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `BASE_URL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `BEARER_ONLY` bit(1) NOT NULL DEFAULT b'0',
  `MANAGEMENT_URL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `SURROGATE_AUTH_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PROTOCOL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NODE_REREG_TIMEOUT` int(11) NULL DEFAULT 0,
  `FRONTCHANNEL_LOGOUT` bit(1) NOT NULL DEFAULT b'0',
  `CONSENT_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `SERVICE_ACCOUNTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `CLIENT_AUTHENTICATOR_TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ROOT_URL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `REGISTRATION_TOKEN` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `STANDARD_FLOW_ENABLED` bit(1) NOT NULL DEFAULT b'1',
  `IMPLICIT_FLOW_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DIRECT_ACCESS_GRANTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `ALWAYS_DISPLAY_IN_CONSOLE` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_B71CJLBENV945RB6GCON438AT`(`REALM_ID`, `CLIENT_ID`) USING BTREE,
  INDEX `IDX_CLIENT_ID`(`CLIENT_ID`) USING BTREE,
  CONSTRAINT `FK_P56CTINXXB9GSK57FO49F9TAC` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT
-- ----------------------------
INSERT INTO `CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', b'0', 'account', 0, b'0', '**********', '/realms/baeldung/account/', b'0', NULL, b'0', 'baeldung', 'openid-connect', 0, b'0', b'0', '${client_account}', b'0', 'client-secret', '${authBaseUrl}', NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', b'1', b'0', 'admin-cli', 0, b'1', '**********', NULL, b'0', NULL, b'0', 'baeldung', 'openid-connect', 0, b'0', b'0', '${client_admin-cli}', b'0', 'client-secret', NULL, NULL, NULL, b'0', b'0', b'1', b'0');
INSERT INTO `CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', b'1', b'0', 'broker', 0, b'0', '**********', NULL, b'0', NULL, b'0', 'baeldung', 'openid-connect', 0, b'0', b'0', '${client_broker}', b'0', 'client-secret', NULL, NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', b'1', b'0', 'account-console', 0, b'1', '0a91fd7f-d4ae-4f38-966d-f75bb56731b8', '/realms/baeldung/account/', b'0', NULL, b'0', 'baeldung', 'openid-connect', 0, b'0', b'0', '${client_account-console}', b'0', 'client-secret', '${authBaseUrl}', NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', b'0', 'account', 0, b'0', '779a18d3-83aa-47ea-ae71-fd3aebc791d1', '/realms/master/account/', b'0', NULL, b'0', 'master', 'openid-connect', 0, b'0', b'0', '${client_account}', b'0', 'client-secret', '${authBaseUrl}', NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', b'1', b'0', 'realm-management', 0, b'0', '**********', NULL, b'1', NULL, b'0', 'baeldung', 'openid-connect', 0, b'0', b'0', '${client_realm-management}', b'0', 'client-secret', NULL, NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', b'1', b'0', 'account-console', 0, b'1', 'cd0ecacf-af57-44b4-9c40-3712600c10dd', '/realms/master/account/', b'0', NULL, b'0', 'master', 'openid-connect', 0, b'0', b'0', '${client_account-console}', b'0', 'client-secret', '${authBaseUrl}', NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', b'1', b'0', 'security-admin-console', 0, b'1', '**********', '/admin/baeldung/console/', b'0', NULL, b'0', 'baeldung', 'openid-connect', 0, b'0', b'0', '${client_security-admin-console}', b'0', 'client-secret', '${authAdminUrl}', NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', b'1', b'0', 'security-admin-console', 0, b'1', 'a0329006-84eb-40ef-9550-f178203a54b0', '/admin/master/console/', b'0', NULL, b'0', 'master', 'openid-connect', 0, b'0', b'0', '${client_security-admin-console}', b'0', 'client-secret', '${authAdminUrl}', NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', b'1', 'baeldung-realm', 0, b'0', '5b64b0be-493c-40b8-a063-625fa5bbe822', NULL, b'1', NULL, b'0', 'master', NULL, 0, b'0', b'0', 'baeldung Realm', b'0', 'client-secret', NULL, NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', b'1', 'master-realm', 0, b'0', '870d8d00-673b-4da0-a895-2697c6299b11', NULL, b'1', NULL, b'0', 'master', NULL, 0, b'0', b'0', 'master Realm', b'0', 'client-secret', NULL, NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', b'1', b'0', 'broker', 0, b'0', 'efc79b55-7ea8-40c4-a821-92b44eda4eeb', NULL, b'0', NULL, b'0', 'master', 'openid-connect', 0, b'0', b'0', '${client_broker}', b'0', 'client-secret', NULL, NULL, NULL, b'1', b'0', b'0', b'0');
INSERT INTO `CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', b'1', b'0', 'admin-cli', 0, b'1', '2660f4d5-1f64-4dbb-a70d-ae7df2ebde87', NULL, b'0', NULL, b'0', 'master', 'openid-connect', 0, b'0', b'0', '${client_admin-cli}', b'0', 'client-secret', NULL, NULL, NULL, b'0', b'0', b'1', b'0');
INSERT INTO `CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', b'1', b'1', 'newClient', 0, b'0', 'newClientSecret', NULL, b'0', NULL, b'0', 'baeldung', 'openid-connect', -1, b'0', b'0', NULL, b'0', 'client-secret', NULL, NULL, NULL, b'1', b'1', b'1', b'0');

-- ----------------------------
-- Table structure for CLIENT_ATTRIBUTES
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_ATTRIBUTES`;
CREATE TABLE `CLIENT_ATTRIBUTES`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(4000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK3C47C64BEACCA966` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_ATTRIBUTES
-- ----------------------------
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', 'S256', 'pkce.code.challenge.method');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', 'S256', 'pkce.code.challenge.method');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', 'S256', 'pkce.code.challenge.method');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', 'S256', 'pkce.code.challenge.method');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'display.on.consent.screen');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'exclude.session.state.from.auth.response');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.assertion.signature');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.authnstatement');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.client.signature');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.encrypt');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.force.post.binding');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.multivalued.roles');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.onetimeuse.condition');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.server.signature');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml.server.signature.keyinfo.ext');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'saml_force_name_id_format');
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'false', 'tls.client.certificate.bound.access.tokens');

-- ----------------------------
-- Table structure for CLIENT_AUTH_FLOW_BINDINGS
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_AUTH_FLOW_BINDINGS`;
CREATE TABLE `CLIENT_AUTH_FLOW_BINDINGS`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FLOW_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `BINDING_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `BINDING_NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_AUTH_FLOW_BINDINGS
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_DEFAULT_ROLES
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_DEFAULT_ROLES`;
CREATE TABLE `CLIENT_DEFAULT_ROLES`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `ROLE_ID`) USING BTREE,
  UNIQUE INDEX `UK_8AELWNIBJI49AVXSRTUF6XJOW`(`ROLE_ID`) USING BTREE,
  INDEX `IDX_CLIENT_DEF_ROLES_CLIENT`(`CLIENT_ID`) USING BTREE,
  CONSTRAINT `FK_8AELWNIBJI49AVXSRTUF6XJOW` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_NUILTS7KLWQW2H8M2B5JOYTKY` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_DEFAULT_ROLES
-- ----------------------------
INSERT INTO `CLIENT_DEFAULT_ROLES` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '8daa8096-d14e-4d1c-ad1f-83f822016aa1');
INSERT INTO `CLIENT_DEFAULT_ROLES` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', 'aed18201-2433-4998-8fa3-0979b0b31c10');
INSERT INTO `CLIENT_DEFAULT_ROLES` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', 'cfb69f93-bbe2-48c2-b903-5cb16d1abf5c');
INSERT INTO `CLIENT_DEFAULT_ROLES` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', 'd3cad871-4b66-4016-b662-72446741e63d');

-- ----------------------------
-- Table structure for CLIENT_INITIAL_ACCESS
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_INITIAL_ACCESS`;
CREATE TABLE `CLIENT_INITIAL_ACCESS`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TIMESTAMP` int(11) NULL DEFAULT NULL,
  `EXPIRATION` int(11) NULL DEFAULT NULL,
  `COUNT` int(11) NULL DEFAULT NULL,
  `REMAINING_COUNT` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_CLIENT_INIT_ACC_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_CLIENT_INIT_ACC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_INITIAL_ACCESS
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_NODE_REGISTRATIONS
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_NODE_REGISTRATIONS`;
CREATE TABLE `CLIENT_NODE_REGISTRATIONS`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` int(11) NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK4129723BA992F594` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_NODE_REGISTRATIONS
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_SCOPE
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SCOPE`;
CREATE TABLE `CLIENT_SCOPE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `PROTOCOL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_CLI_SCOPE`(`REALM_ID`, `NAME`) USING BTREE,
  INDEX `IDX_REALM_CLSCOPE`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_REALM_CLI_SCOPE` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SCOPE
-- ----------------------------
INSERT INTO `CLIENT_SCOPE` VALUES ('0c3005e6-8f78-4da7-b654-73643ab087d8', 'web-origins', 'master', 'OpenID Connect scope for add allowed web origins to the access token', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', 'roles', 'baeldung', 'OpenID Connect scope for add user roles to the access token', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('18e141bf-dabe-4858-879c-dbc439cdead4', 'role_list', 'baeldung', 'SAML role list', 'saml');
INSERT INTO `CLIENT_SCOPE` VALUES ('4308b568-d494-4a27-bcbb-44f510348cee', 'email', 'master', 'OpenID Connect built-in scope: email', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('51d49314-b511-43e0-9258-bfb873758a78', 'web-origins', 'baeldung', 'OpenID Connect scope for add allowed web origins to the access token', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('569b3d44-4ecd-4768-a58c-70ff38f4b4fe', 'offline_access', 'baeldung', 'OpenID Connect built-in scope: offline_access', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('6ea576db-f1ca-421d-b96b-1b08cf69131d', 'microprofile-jwt', 'master', 'Microprofile - JWT built-in scope', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('7003f9b2-6302-4e25-9e06-2aff252a9612', 'offline_access', 'master', 'OpenID Connect built-in scope: offline_access', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('77c7e29d-1a22-4419-bbfb-4a62bb033449', 'address', 'baeldung', 'OpenID Connect built-in scope: address', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('84a20307-7989-4455-9a8f-b338704a2f2b', 'profile', 'master', 'OpenID Connect built-in scope: profile', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('89860f9b-8982-4ded-a6a0-b7f75a8447e6', 'role_list', 'master', 'SAML role list', 'saml');
INSERT INTO `CLIENT_SCOPE` VALUES ('a3e7b19d-df6c-437e-9eea-06fec1becb2f', 'phone', 'baeldung', 'OpenID Connect built-in scope: phone', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('b3526ac1-10e2-4344-8621-9c5a0853e97a', 'email', 'baeldung', 'OpenID Connect built-in scope: email', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('ba8c9950-fd0b-4434-8be6-b58456d7b6d4', 'profile', 'baeldung', 'OpenID Connect built-in scope: profile', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('c1a2eb23-25c6-4be7-a791-bbdca99c83f7', 'read', 'baeldung', NULL, 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('c3e253fb-7361-47cf-9d4a-86245686fdf1', 'write', 'baeldung', NULL, 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('c658ae14-e96a-4745-b21b-2ed5c4c63f5f', 'microprofile-jwt', 'baeldung', 'Microprofile - JWT built-in scope', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('d0359686-f867-4687-a7f1-1fe43386e1ed', 'phone', 'master', 'OpenID Connect built-in scope: phone', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('d7f50591-889b-4f3a-9e2b-dc16e253b133', 'roles', 'master', 'OpenID Connect scope for add user roles to the access token', 'openid-connect');
INSERT INTO `CLIENT_SCOPE` VALUES ('e5510191-5adb-483f-ad0a-eb363f0a75b7', 'address', 'master', 'OpenID Connect built-in scope: address', 'openid-connect');

-- ----------------------------
-- Table structure for CLIENT_SCOPE_ATTRIBUTES
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SCOPE_ATTRIBUTES`;
CREATE TABLE `CLIENT_SCOPE_ATTRIBUTES`  (
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(2048) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`, `NAME`) USING BTREE,
  INDEX `IDX_CLSCOPE_ATTRS`(`SCOPE_ID`) USING BTREE,
  CONSTRAINT `FK_CL_SCOPE_ATTR_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SCOPE_ATTRIBUTES
-- ----------------------------
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('0c3005e6-8f78-4da7-b654-73643ab087d8', '', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('0c3005e6-8f78-4da7-b654-73643ab087d8', 'false', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('0c3005e6-8f78-4da7-b654-73643ab087d8', 'false', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', '${rolesScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', 'false', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('18e141bf-dabe-4858-879c-dbc439cdead4', '${samlRoleListScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('18e141bf-dabe-4858-879c-dbc439cdead4', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('4308b568-d494-4a27-bcbb-44f510348cee', '${emailScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('4308b568-d494-4a27-bcbb-44f510348cee', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('4308b568-d494-4a27-bcbb-44f510348cee', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('51d49314-b511-43e0-9258-bfb873758a78', '', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('51d49314-b511-43e0-9258-bfb873758a78', 'false', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('51d49314-b511-43e0-9258-bfb873758a78', 'false', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('569b3d44-4ecd-4768-a58c-70ff38f4b4fe', '${offlineAccessScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('569b3d44-4ecd-4768-a58c-70ff38f4b4fe', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('6ea576db-f1ca-421d-b96b-1b08cf69131d', 'false', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('6ea576db-f1ca-421d-b96b-1b08cf69131d', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('7003f9b2-6302-4e25-9e06-2aff252a9612', '${offlineAccessScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('7003f9b2-6302-4e25-9e06-2aff252a9612', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('77c7e29d-1a22-4419-bbfb-4a62bb033449', '${addressScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('77c7e29d-1a22-4419-bbfb-4a62bb033449', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('77c7e29d-1a22-4419-bbfb-4a62bb033449', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('84a20307-7989-4455-9a8f-b338704a2f2b', '${profileScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('84a20307-7989-4455-9a8f-b338704a2f2b', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('84a20307-7989-4455-9a8f-b338704a2f2b', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('89860f9b-8982-4ded-a6a0-b7f75a8447e6', '${samlRoleListScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('89860f9b-8982-4ded-a6a0-b7f75a8447e6', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('a3e7b19d-df6c-437e-9eea-06fec1becb2f', '${phoneScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('a3e7b19d-df6c-437e-9eea-06fec1becb2f', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('a3e7b19d-df6c-437e-9eea-06fec1becb2f', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('b3526ac1-10e2-4344-8621-9c5a0853e97a', '${emailScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('b3526ac1-10e2-4344-8621-9c5a0853e97a', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('b3526ac1-10e2-4344-8621-9c5a0853e97a', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('ba8c9950-fd0b-4434-8be6-b58456d7b6d4', '${profileScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('ba8c9950-fd0b-4434-8be6-b58456d7b6d4', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('ba8c9950-fd0b-4434-8be6-b58456d7b6d4', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('c1a2eb23-25c6-4be7-a791-bbdca99c83f7', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('c1a2eb23-25c6-4be7-a791-bbdca99c83f7', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('c3e253fb-7361-47cf-9d4a-86245686fdf1', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('c3e253fb-7361-47cf-9d4a-86245686fdf1', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('c658ae14-e96a-4745-b21b-2ed5c4c63f5f', 'false', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('c658ae14-e96a-4745-b21b-2ed5c4c63f5f', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('d0359686-f867-4687-a7f1-1fe43386e1ed', '${phoneScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('d0359686-f867-4687-a7f1-1fe43386e1ed', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('d0359686-f867-4687-a7f1-1fe43386e1ed', 'true', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('d7f50591-889b-4f3a-9e2b-dc16e253b133', '${rolesScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('d7f50591-889b-4f3a-9e2b-dc16e253b133', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('d7f50591-889b-4f3a-9e2b-dc16e253b133', 'false', 'include.in.token.scope');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('e5510191-5adb-483f-ad0a-eb363f0a75b7', '${addressScopeConsentText}', 'consent.screen.text');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('e5510191-5adb-483f-ad0a-eb363f0a75b7', 'true', 'display.on.consent.screen');
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('e5510191-5adb-483f-ad0a-eb363f0a75b7', 'true', 'include.in.token.scope');

-- ----------------------------
-- Table structure for CLIENT_SCOPE_CLIENT
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SCOPE_CLIENT`;
CREATE TABLE `CLIENT_SCOPE_CLIENT`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DEFAULT_SCOPE` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`CLIENT_ID`, `SCOPE_ID`) USING BTREE,
  INDEX `IDX_CLSCOPE_CL`(`CLIENT_ID`) USING BTREE,
  INDEX `IDX_CL_CLSCOPE`(`SCOPE_ID`) USING BTREE,
  CONSTRAINT `FK_C_CLI_SCOPE_CLIENT` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_C_CLI_SCOPE_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SCOPE_CLIENT
-- ----------------------------
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('13d76feb-d762-4409-bb84-7a75bc395a61', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('4b9609f0-48d1-4e71-9381-2ecec08616f9', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('6a4bfbd0-576d-4778-af56-56f876647355', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('ac3c0b02-d013-4345-83f7-dbb2a0550ce6', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b77e3260-787b-4d35-8118-cf686e6f02fa', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b7dad9cc-97f0-4759-b34a-7af6560762f6', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', '51d49314-b511-43e0-9258-bfb873758a78', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'c1a2eb23-25c6-4be7-a791-bbdca99c83f7', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'c3e253fb-7361-47cf-9d4a-86245686fdf1', b'0');
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');

-- ----------------------------
-- Table structure for CLIENT_SCOPE_ROLE_MAPPING
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SCOPE_ROLE_MAPPING`;
CREATE TABLE `CLIENT_SCOPE_ROLE_MAPPING`  (
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`, `ROLE_ID`) USING BTREE,
  INDEX `IDX_CLSCOPE_ROLE`(`SCOPE_ID`) USING BTREE,
  INDEX `IDX_ROLE_CLSCOPE`(`ROLE_ID`) USING BTREE,
  CONSTRAINT `FK_CL_SCOPE_RM_ROLE` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_CL_SCOPE_RM_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SCOPE_ROLE_MAPPING
-- ----------------------------
INSERT INTO `CLIENT_SCOPE_ROLE_MAPPING` VALUES ('569b3d44-4ecd-4768-a58c-70ff38f4b4fe', '3b6109f5-6e5a-4578-83c3-791ec3e2bf9e');
INSERT INTO `CLIENT_SCOPE_ROLE_MAPPING` VALUES ('7003f9b2-6302-4e25-9e06-2aff252a9612', 'a2ec3e99-c78c-44f5-98d7-75c3a26a68cc');

-- ----------------------------
-- Table structure for CLIENT_SESSION
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SESSION`;
CREATE TABLE `CLIENT_SESSION`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REDIRECT_URI` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `STATE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `TIMESTAMP` int(11) NULL DEFAULT NULL,
  `SESSION_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTH_METHOD` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `AUTH_USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CURRENT_ACTION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_CLIENT_SESSION_SESSION`(`SESSION_ID`) USING BTREE,
  CONSTRAINT `FK_B4AO2VCVAT6UKAU74WBWTFQO1` FOREIGN KEY (`SESSION_ID`) REFERENCES `USER_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SESSION
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_SESSION_AUTH_STATUS
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SESSION_AUTH_STATUS`;
CREATE TABLE `CLIENT_SESSION_AUTH_STATUS`  (
  `AUTHENTICATOR` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STATUS` int(11) NULL DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`, `AUTHENTICATOR`) USING BTREE,
  CONSTRAINT `AUTH_STATUS_CONSTRAINT` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SESSION_AUTH_STATUS
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_SESSION_NOTE
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SESSION_NOTE`;
CREATE TABLE `CLIENT_SESSION_NOTE`  (
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`, `NAME`) USING BTREE,
  CONSTRAINT `FK5EDFB00FF51C2736` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SESSION_NOTE
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_SESSION_PROT_MAPPER
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SESSION_PROT_MAPPER`;
CREATE TABLE `CLIENT_SESSION_PROT_MAPPER`  (
  `PROTOCOL_MAPPER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`, `PROTOCOL_MAPPER_ID`) USING BTREE,
  CONSTRAINT `FK_33A8SGQW18I532811V7O2DK89` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SESSION_PROT_MAPPER
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_SESSION_ROLE
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_SESSION_ROLE`;
CREATE TABLE `CLIENT_SESSION_ROLE`  (
  `ROLE_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`, `ROLE_ID`) USING BTREE,
  CONSTRAINT `FK_11B7SGQW18I532811V7O2DV76` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_SESSION_ROLE
-- ----------------------------

-- ----------------------------
-- Table structure for CLIENT_USER_SESSION_NOTE
-- ----------------------------
DROP TABLE IF EXISTS `CLIENT_USER_SESSION_NOTE`;
CREATE TABLE `CLIENT_USER_SESSION_NOTE`  (
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(2048) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`, `NAME`) USING BTREE,
  CONSTRAINT `FK_CL_USR_SES_NOTE` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CLIENT_USER_SESSION_NOTE
-- ----------------------------

-- ----------------------------
-- Table structure for COMPONENT
-- ----------------------------
DROP TABLE IF EXISTS `COMPONENT`;
CREATE TABLE `COMPONENT`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PARENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PROVIDER_TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `SUB_TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_COMPONENT_REALM`(`REALM_ID`) USING BTREE,
  INDEX `IDX_COMPONENT_PROVIDER_TYPE`(`PROVIDER_TYPE`) USING BTREE,
  CONSTRAINT `FK_COMPONENT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of COMPONENT
-- ----------------------------
INSERT INTO `COMPONENT` VALUES ('365b2899-befe-4417-b89b-562650ec4446', 'Full Scope Disabled', 'baeldung', 'scope', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'Allowed Protocol Mapper Types', 'master', 'allowed-protocol-mappers', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'authenticated');
INSERT INTO `COMPONENT` VALUES ('3caaf57a-9cd7-48c1-b709-b40b887414f7', 'Allowed Protocol Mapper Types', 'baeldung', 'allowed-protocol-mappers', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('41ffde1b-72a2-416f-87a7-94989e940dc0', 'Allowed Protocol Mapper Types', 'baeldung', 'allowed-protocol-mappers', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'authenticated');
INSERT INTO `COMPONENT` VALUES ('48d40de3-6234-42e8-9449-f68f56abb54b', 'aes-generated', 'baeldung', 'aes-generated', 'org.keycloak.keys.KeyProvider', 'baeldung', NULL);
INSERT INTO `COMPONENT` VALUES ('4c8bd74c-45d7-4326-aa59-3d4a93f1295c', 'Full Scope Disabled', 'master', 'scope', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('52ea1c5d-2a30-459f-b66a-249f298b32f8', 'hmac-generated', 'baeldung', 'hmac-generated', 'org.keycloak.keys.KeyProvider', 'baeldung', NULL);
INSERT INTO `COMPONENT` VALUES ('5f2adee4-6fc2-4193-bcce-3e775bf1f012', 'Allowed Client Scopes', 'master', 'allowed-client-templates', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'authenticated');
INSERT INTO `COMPONENT` VALUES ('609ee4aa-879f-41c6-8eee-81d469f30fa8', 'Allowed Client Scopes', 'master', 'allowed-client-templates', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('7336232a-f2b5-4e4a-be0b-b9cd140d430d', 'Trusted Hosts', 'master', 'trusted-hosts', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('76075388-2782-4656-a986-313493239a9f', 'Consent Required', 'baeldung', 'consent-required', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'Allowed Protocol Mapper Types', 'master', 'allowed-protocol-mappers', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('81c32244-7921-43e9-9356-a3469259b78c', 'Trusted Hosts', 'baeldung', 'trusted-hosts', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('84305f42-4b6d-4b0a-ac7c-53e406e3ac63', 'Allowed Client Scopes', 'baeldung', 'allowed-client-templates', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'authenticated');
INSERT INTO `COMPONENT` VALUES ('bb9d4d55-6d24-4e50-9169-f685808a22a2', 'Max Clients Limit', 'master', 'max-clients', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('bf71b811-53ea-42a8-9f95-2e4e7df9c14d', 'Consent Required', 'master', 'consent-required', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'master', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('c7c38a95-744f-4558-a403-9cf692fe1944', 'Allowed Client Scopes', 'baeldung', 'allowed-client-templates', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('d09b2147-afea-4f7f-a49c-0aec7eee10de', 'Max Clients Limit', 'baeldung', 'max-clients', 'org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy', 'baeldung', 'anonymous');
INSERT INTO `COMPONENT` VALUES ('d67a940a-52e4-44a5-9f69-6ffdd67a188f', 'rsa-generated', 'baeldung', 'rsa-generated', 'org.keycloak.keys.KeyProvider', 'baeldung', NULL);

-- ----------------------------
-- Table structure for COMPONENT_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `COMPONENT_CONFIG`;
CREATE TABLE `COMPONENT_CONFIG`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `COMPONENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_COMPO_CONFIG_COMPO`(`COMPONENT_ID`) USING BTREE,
  CONSTRAINT `FK_COMPONENT_CONFIG` FOREIGN KEY (`COMPONENT_ID`) REFERENCES `COMPONENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of COMPONENT_CONFIG
-- ----------------------------
INSERT INTO `COMPONENT_CONFIG` VALUES ('0d6f8a61-7b57-4aac-b7e8-4f93f64e4898', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'oidc-usermodel-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('0e990ff2-8c98-41c7-a83c-827a0a54ec6f', 'd09b2147-afea-4f7f-a49c-0aec7eee10de', 'max-clients', '200');
INSERT INTO `COMPONENT_CONFIG` VALUES ('18877e9d-e046-409e-b071-d93d295d543a', '48d40de3-6234-42e8-9449-f68f56abb54b', 'secret', 'KH8ObwyJF_YZ6pJ5v9YPuA');
INSERT INTO `COMPONENT_CONFIG` VALUES ('1a5f5b43-25de-40b7-8060-4126570fac46', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'oidc-address-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('1dd34841-3a42-4d76-b519-c74da9bfaf59', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'oidc-address-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('2f6d2085-e3c5-4463-97b7-6ecea9b3c6fb', '7336232a-f2b5-4e4a-be0b-b9cd140d430d', 'host-sending-registration-request-must-match', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('327e168f-8771-46aa-8998-8c173078c89c', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'oidc-sha256-pairwise-sub-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('3fb0ec80-b912-4a36-8957-4098d73c2015', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'saml-user-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('44214254-211b-4884-a249-77d878911c53', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'saml-user-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('445e02e3-06b6-4d30-9b78-4ddb5621552c', '84305f42-4b6d-4b0a-ac7c-53e406e3ac63', 'allow-default-scopes', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('4725676e-fb34-4eff-ba08-460a4d3a4af4', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'oidc-address-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('4ff04bb1-ac45-4879-97ca-471e90bb235e', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'oidc-full-name-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('523ab97e-8dbf-4963-ab67-30a71f82a62a', '7336232a-f2b5-4e4a-be0b-b9cd140d430d', 'client-uris-must-match', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('53202bdb-9de4-416d-899d-1e3ff2d9a268', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'oidc-usermodel-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('57ae136e-d535-44f6-8518-cfd3d017b69f', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'oidc-usermodel-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('5a220f5e-aaf4-4dcf-8055-7fd2998ff710', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'oidc-usermodel-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('5b395d7f-5a6e-4b26-a6e9-e6cbed36ec93', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'oidc-sha256-pairwise-sub-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('5cc2e97c-fc26-4a31-bf3b-d3f1693d9553', 'c7c38a95-744f-4558-a403-9cf692fe1944', 'allow-default-scopes', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('5e592c36-f27e-4041-b5a4-904f4caf3470', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'saml-role-list-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('65ecfa5c-e1f1-4b58-9ace-59e82c63a156', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'saml-user-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('663c07f2-c6de-4da1-b401-9515551ab839', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'oidc-full-name-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('6974e70a-d3e0-4982-8b82-af8c3eacf2d0', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'oidc-sha256-pairwise-sub-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('6d65a7ee-c66d-48ed-a04b-366439992022', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'saml-user-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('70cf8104-c263-40ad-a3ad-f052c93ed2c3', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'oidc-full-name-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('813986a6-a0ca-41d8-89ae-8cacd75005c6', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'saml-role-list-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('85236fce-8185-49d6-9cd8-f10b8525244b', '48d40de3-6234-42e8-9449-f68f56abb54b', 'priority', '100');
INSERT INTO `COMPONENT_CONFIG` VALUES ('9a75ac00-172f-4081-a6bd-c610081f3ccf', 'd67a940a-52e4-44a5-9f69-6ffdd67a188f', 'privateKey', 'MIIEpQIBAAKCAQEAsw+lmV2HbpgXllKS+ccyCerlWDir32Y3yFvXF3CbzYRKVg/4FddA8itMCPpPjVOAo26bi/0WImHHYPyGxSH3QQIQaSdS5AFUNarpFc9M/W4Bu7k5h8sKb+vzZA3hMLFyvmQ2JtY8Zuqi1BBB33OAlkOHprJFTrrt1xa4a6KJjKXlDp5o5hOFgvZbsW+k/fBU0CLCbL3PlXQLhqHgEncpL9L9FF/xDbPIGftxjEWcBPFG/SuyygT35xRFMxB7ifR+wJZwVnoC4RhbhgJdL2EiUVT7wq5MTsxr2j4nAAJYatK/7OTecs6y/7bGNAGEoqh4Q3X3D95YFex0scmHgY1hWwIDAQABAoIBAQCAesmnsaRrhlXmVnl/H56X3yOQmZk5Qm7kJIHBH9urKzDrb6niggDnwolcJ77M+Q1kNwkE+SPYp7AXtxo8eJKg4opD6SNg1lNF7swwCf6EGVrFB7Jv7RAgHn0VXaAnACwE0ILKew38Cn+rCb86RfYN24aJ5YA1bYsaugK5uHZZo7kLnv5PUwOwu4PqhAKLPyQt2P1gN3rzf0TGmL5Ylqoxx6X6QBKTwOqAzsWPshMxOB+GzIDDegvzQ6UIV/FzsxIZFLVAPtAWxa77TgT8LeBxDz/UF3H5cWEP5LJ3108ZUOa/EyPiIAaMsLtgVycf7gtsOEsQ4q/OqqJrL4NdNUaBAoGBAPVeguDaUwZIMOYGH2sjYaShaddMFsR2u93dj/GI/T8A4/iXz2yxfHl0LEmxQpZkzyVFpYkYO54w59zLdhzpFOkuGOMT+1j4FnMEjSnzQhZzLVxwuQ9cX0VhYRf+gpwhUOrmbPZB3tYWIiDGm823c6J4QCi0kG5R7pPb/nowpIulAoGBALrRr6RdL/lqrt/REtVW2KSdL6r38sN12vmgjBzIQFLWQFSzDxjaPLeZY87uIhpAWAuZJW+NZ7WfF85WuKDwSbuoZ1ln1yj3FkJkYZmdOid8VpEam2Z9sCncvbAq/pvhgSKMYZeXQ2+dPM0N1HiDb9SEuPIbS3hvcYwNAcLyWqj/AoGBAOfAmMVf8MMiNG1OoyZCiNtCSgG8MFToAJGRz39G8EstwCTw3k2/Zd4hSCNidY4vMSf3HF7csJK9hoIY+jpcPA/yJjd0jBaAXFPOnLZeuLEToGiLX3+Os72IOHi9PwfQv+jeM1R06tAyn5FthYNMHr/57D+GLFTGthyZ0UX/46qxAoGAJ7ENRDqYSsGjzeG5wqHk/XR4ADcV2PldQNQfcK4LHI5wtI4mkv0rEUcBsaFelX0+N5ieH4lHk4rtn+VE7MygncI10wUA7a8xh4GUSvLgvCrqqYGhqrDhkMNZeehol+3dZd21jmOQ7FHX7SkXD1O9msVoFeg+rKPg2ASbbzPWlzkCgYEAgVQKaTCgh3E2z3E9OhzeMIq7qyJuSKsP5FHsTT17U46/rPk+XBhLB/VBkY0Hn29NW4CWTmvEaJrJiejKJaPap8DBjMpJ7KnMidEeHaRykCuPmi9VUT2Q+FE5lQaPi8fYIlHI7BsIY+wTVlKRezkKpuFezocyP5YR34XDkM0BhRI=');
INSERT INTO `COMPONENT_CONFIG` VALUES ('9c9d7161-20d6-4182-bb48-378335e6b74e', '52ea1c5d-2a30-459f-b66a-249f298b32f8', 'priority', '100');
INSERT INTO `COMPONENT_CONFIG` VALUES ('a6f88982-9c4a-4cff-9e59-bc7ec5ecaa88', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'oidc-usermodel-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('ad1356c4-e58a-4f47-b7da-0f69a30fdd0c', 'd67a940a-52e4-44a5-9f69-6ffdd67a188f', 'certificate', 'MIICnzCCAYcCBgFuhB77/jANBgkqhkiG9w0BAQsFADATMREwDwYDVQQDDAhiYWVsZHVuZzAeFw0xOTExMTkxNDQyMzNaFw0yOTExMTkxNDQ0MTNaMBMxETAPBgNVBAMMCGJhZWxkdW5nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsw+lmV2HbpgXllKS+ccyCerlWDir32Y3yFvXF3CbzYRKVg/4FddA8itMCPpPjVOAo26bi/0WImHHYPyGxSH3QQIQaSdS5AFUNarpFc9M/W4Bu7k5h8sKb+vzZA3hMLFyvmQ2JtY8Zuqi1BBB33OAlkOHprJFTrrt1xa4a6KJjKXlDp5o5hOFgvZbsW+k/fBU0CLCbL3PlXQLhqHgEncpL9L9FF/xDbPIGftxjEWcBPFG/SuyygT35xRFMxB7ifR+wJZwVnoC4RhbhgJdL2EiUVT7wq5MTsxr2j4nAAJYatK/7OTecs6y/7bGNAGEoqh4Q3X3D95YFex0scmHgY1hWwIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCLf01IsqWCKF2vw5y/NPCgKFEP4vtlXvr1XusMr9sAMSgbAVKLm5wZg4Ue8Q7iUq1LJzZ7EOeaXfIHxk33vjf0RlJQAaVn2K/kZJ4rFXuU6g+mpoRgiFsCPNexXXMdG294osyJ60g5OWCt5KrdocFjkKbF9EYm2CBj20G5MxCf+VDGDIcNvgzp478CZODiFVb6JgQqRrE3CGzQKdKiHG9cbXAledMJuWw3h0dzAqM46nl7GRkNK2cmVJO+cDD7xMrD83Q84PoG1ixMsQ/Tv5CqfREC4Dp9/j4XaoEOJ5S7oBaiRqTMzxk/lPjmbUrdyLM0Kokrrwc2yF74m9NuwHh2');
INSERT INTO `COMPONENT_CONFIG` VALUES ('b148861f-2a57-4317-8620-86be16e5d75a', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'saml-role-list-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('b22739bd-e6db-478d-ba93-939230cd270c', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'oidc-usermodel-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('b279ee0a-e942-43d9-ac99-3f70787e152a', '5f2adee4-6fc2-4193-bcce-3e775bf1f012', 'allow-default-scopes', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('b96eb409-105d-4807-b9f6-954a19464aed', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'saml-user-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('c1cc99d4-78de-44d8-96d6-2c369f3556ab', '81c32244-7921-43e9-9356-a3469259b78c', 'host-sending-registration-request-must-match', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('c5bb30cb-aa10-4fcd-85be-762973df09a0', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'saml-role-list-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('d404b096-52d2-4401-b684-6f3c5a936d00', '609ee4aa-879f-41c6-8eee-81d469f30fa8', 'allow-default-scopes', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('ddd0759c-2e4e-4822-98d1-2e685af5ca13', '3caaf57a-9cd7-48c1-b709-b40b887414f7', 'allowed-protocol-mapper-types', 'saml-user-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e079b87b-b2a4-44ad-a7c9-2dd28ffaf6f5', '52ea1c5d-2a30-459f-b66a-249f298b32f8', 'kid', '0d90cbd7-7164-42cc-88e2-d215e79ae8ea');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e1f40301-c7fd-40b5-9648-06c4149ae1cc', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'oidc-usermodel-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e44037ac-bf5f-4823-afa7-d77121b6a65b', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'saml-user-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e44d4c42-0368-4e67-850d-ecb0ff7b1766', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'oidc-usermodel-attribute-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e498bd36-4656-4ffd-9505-d7d0dd38a838', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'oidc-address-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e5a29d64-807c-48be-a1d5-91ed11e0125c', '52ea1c5d-2a30-459f-b66a-249f298b32f8', 'secret', 'AFOsLJGAelu021azV_tqcT4qhune3A0xfvGZiqfdTCBcC2UAAErphg1Q3FC4eET83w8uDyi3CMtD1v-6lXqhqw');
INSERT INTO `COMPONENT_CONFIG` VALUES ('e6242ea5-996f-48de-a8d7-97359ebaafa6', '52ea1c5d-2a30-459f-b66a-249f298b32f8', 'algorithm', 'HS256');
INSERT INTO `COMPONENT_CONFIG` VALUES ('ef4a06fc-dc85-468f-ad63-ca3e0672c2c3', 'bb9d4d55-6d24-4e50-9169-f685808a22a2', 'max-clients', '200');
INSERT INTO `COMPONENT_CONFIG` VALUES ('f02480df-e71d-422b-926d-e9bb82ae78b8', '41ffde1b-72a2-416f-87a7-94989e940dc0', 'allowed-protocol-mapper-types', 'saml-user-property-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('f091441e-f7e9-42cf-b7b3-57cde1553575', '81c32244-7921-43e9-9356-a3469259b78c', 'client-uris-must-match', 'true');
INSERT INTO `COMPONENT_CONFIG` VALUES ('f394e581-d188-48b3-a257-4067b5b1e8c3', '79687d78-bbe9-4bcf-a47a-ba5b4d0a1b1a', 'allowed-protocol-mapper-types', 'oidc-sha256-pairwise-sub-mapper');
INSERT INTO `COMPONENT_CONFIG` VALUES ('f41e0501-9eb5-40d0-8c6c-6c764dc9a0f8', 'd67a940a-52e4-44a5-9f69-6ffdd67a188f', 'priority', '100');
INSERT INTO `COMPONENT_CONFIG` VALUES ('f58f9c94-6ca6-46f8-a9f4-b4eba68158cb', '48d40de3-6234-42e8-9449-f68f56abb54b', 'kid', 'a1643e07-7de0-4265-a42b-21152b16f2a5');
INSERT INTO `COMPONENT_CONFIG` VALUES ('f5c9d1f8-4f88-4563-82a8-ac95e3ed8d5e', '3934fa3d-83da-46d3-8dbd-f3b73d8da4c1', 'allowed-protocol-mapper-types', 'oidc-full-name-mapper');

-- ----------------------------
-- Table structure for COMPOSITE_ROLE
-- ----------------------------
DROP TABLE IF EXISTS `COMPOSITE_ROLE`;
CREATE TABLE `COMPOSITE_ROLE`  (
  `COMPOSITE` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CHILD_ROLE` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`COMPOSITE`, `CHILD_ROLE`) USING BTREE,
  INDEX `IDX_COMPOSITE`(`COMPOSITE`) USING BTREE,
  INDEX `IDX_COMPOSITE_CHILD`(`CHILD_ROLE`) USING BTREE,
  CONSTRAINT `FK_A63WVEKFTU8JO1PNJ81E7MCE2` FOREIGN KEY (`COMPOSITE`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_GR7THLLB9LU8Q4VQA4524JJY8` FOREIGN KEY (`CHILD_ROLE`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of COMPOSITE_ROLE
-- ----------------------------
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '0332e99b-3dfc-4193-9e13-5728f8f3e6d6');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '0f8e5ee8-b014-4b7c-9b69-50f46abcba5f');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '387418b1-4f80-4b00-b9dd-805ca041f805');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '3ea43b64-316f-4693-8346-9ee78b24adaf');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '49735614-96ec-49b2-98fe-3af9bcd1a33a');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '5d00243f-ceec-4b0c-995e-d86d5b8a0ae6');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '5d48274c-bd6b-4c26-ad54-f1a2254beac0');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '5ea9810d-63cc-4277-9b32-ba8a3d3c6091');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '6eedf2b7-50ef-4495-a89b-54aef751b7fa');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '8b7b0dd8-350b-473e-b8cd-8acad34f1358');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '911b1489-9383-4734-b134-bf49bf992ce9');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '941612de-bd85-47a5-8dfa-37c270dde28c');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', 'a574cf01-03e4-4573-ab9e-276d13a1ce8d');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', 'aac3def5-f193-4a6c-9065-1667a0746a8a');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', 'b690cb9c-0f4a-4be5-ade0-b40443d8149d');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', 'c3a253a8-a1b6-4d38-9677-f728f32482ad');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', 'e8f8c3cc-0ff1-4f72-a271-db6821a3cdb6');
INSERT INTO `COMPOSITE_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', 'f3cb93da-273e-419a-b2f4-93f09896abcf');
INSERT INTO `COMPOSITE_ROLE` VALUES ('50831bfa-1251-49f9-b213-71bea42201d3', '7ddc5c9d-3866-48c8-b40d-5c1437ef69cd');
INSERT INTO `COMPOSITE_ROLE` VALUES ('5d00243f-ceec-4b0c-995e-d86d5b8a0ae6', '8b7b0dd8-350b-473e-b8cd-8acad34f1358');
INSERT INTO `COMPOSITE_ROLE` VALUES ('5dc206f4-98ce-4dec-a2b9-c3a92db168ed', '7b788da9-b489-4194-baee-9c9b9734e35c');
INSERT INTO `COMPOSITE_ROLE` VALUES ('5dc206f4-98ce-4dec-a2b9-c3a92db168ed', 'f2c4fe67-9edd-4bef-b08c-9aab1c4f1834');
INSERT INTO `COMPOSITE_ROLE` VALUES ('8daa8096-d14e-4d1c-ad1f-83f822016aa1', '948269c7-a69c-4c82-a7f3-88868713dfd9');
INSERT INTO `COMPOSITE_ROLE` VALUES ('9ba11c9d-1495-473e-afd8-ae12a6e06942', 'cba59569-8855-472e-8be7-ac92caa24013');
INSERT INTO `COMPOSITE_ROLE` VALUES ('ab756dee-ebb4-4c4b-aa1c-c4748893ba8c', '8fb2a38f-8d10-4d8c-b08a-8d3c1a2f1f03');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '03b26584-c1d4-460d-b9f1-adbe2573b30e');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '157cecb7-fd8e-47e6-b974-4a5a634da92c');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '201aa378-e0d1-4b03-84af-f0037a8eb134');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '29c66503-2c2e-4bad-a765-78941959694e');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '34f6853d-2c63-429f-a854-7d69f598fcb3');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '454e77e7-3078-4408-a440-c762f95e09bf');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '50831bfa-1251-49f9-b213-71bea42201d3');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '5dc206f4-98ce-4dec-a2b9-c3a92db168ed');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '5f7bd5a2-cbb6-4d4f-8682-7dde4b1b6462');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '74a9ebdd-c052-4e5b-a77a-b9ae3f61c312');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '7b788da9-b489-4194-baee-9c9b9734e35c');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '7ddc5c9d-3866-48c8-b40d-5c1437ef69cd');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '842f6725-b2f8-4466-b68d-cc21dd79f8b3');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '9931cf33-5ccd-4758-bac4-6c6f948e1208');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '9ba11c9d-1495-473e-afd8-ae12a6e06942');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'a29eabe9-ae8a-442d-af22-05d79b7fcf89');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'a9064aa3-693c-4c68-8538-8e7bd8bddf9f');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'ae28ef63-cb12-4a38-94bc-789e5b91e637');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'b2d774c2-fd76-4c13-9715-1f23355214ff');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'b6054436-0871-4ffb-b03d-208237b30035');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'b66a775d-c41c-4c16-87d0-07a4a343241f');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'bc78f00d-e105-40df-a689-b7357ed3a3b7');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'bda0bf27-5fc7-4417-9013-3af6b9c1e216');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'c2de88cd-4d5a-41ef-9b1b-2a72e36fc97e');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'c49b7f4e-a062-4fb8-a222-c5608b7263b8');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'c55d3dff-aee0-46ca-a1c8-e5a759694f5a');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'c66c0d31-77b1-4e94-9da2-f8049cf9736d');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'c7692f82-11da-4bc1-adb0-acc34fce0a4d');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'cba59569-8855-472e-8be7-ac92caa24013');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'd908a88f-863e-4937-a460-78fee0df71f9');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'e295c16e-3560-4e37-99aa-da5a7407fce2');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'eb14e8e5-6236-4888-b146-fcd810569ef7');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'ecd130aa-767a-4684-85f8-3e0d1d6829b0');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'ee1ca19e-ca29-424c-898f-47accb0f64d9');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'f2c4fe67-9edd-4bef-b08c-9aab1c4f1834');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'f389fc9f-3e07-4347-ac1a-15a090980a9d');
INSERT INTO `COMPOSITE_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'fa905288-27f5-4231-8f95-8dde7d1f1ed8');
INSERT INTO `COMPOSITE_ROLE` VALUES ('bc78f00d-e105-40df-a689-b7357ed3a3b7', '29c66503-2c2e-4bad-a765-78941959694e');
INSERT INTO `COMPOSITE_ROLE` VALUES ('bc78f00d-e105-40df-a689-b7357ed3a3b7', 'd908a88f-863e-4937-a460-78fee0df71f9');
INSERT INTO `COMPOSITE_ROLE` VALUES ('c58d42a7-515c-405e-8993-0d5ef6ab8d7f', 'abd59d44-a1aa-4f80-a8d3-2f8219f320ec');
INSERT INTO `COMPOSITE_ROLE` VALUES ('d3cad871-4b66-4016-b662-72446741e63d', 'a3cdd917-d29b-409d-90a5-99f2575aee41');
INSERT INTO `COMPOSITE_ROLE` VALUES ('f3cb93da-273e-419a-b2f4-93f09896abcf', '0f8e5ee8-b014-4b7c-9b69-50f46abcba5f');
INSERT INTO `COMPOSITE_ROLE` VALUES ('f3cb93da-273e-419a-b2f4-93f09896abcf', 'a574cf01-03e4-4573-ab9e-276d13a1ce8d');

-- ----------------------------
-- Table structure for CREDENTIAL
-- ----------------------------
DROP TABLE IF EXISTS `CREDENTIAL`;
CREATE TABLE `CREDENTIAL`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SALT` tinyblob NULL,
  `TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CREATED_DATE` bigint(20) NULL DEFAULT NULL,
  `USER_LABEL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `SECRET_DATA` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `CREDENTIAL_DATA` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `PRIORITY` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_USER_CREDENTIAL`(`USER_ID`) USING BTREE,
  CONSTRAINT `FK_PFYR0GLASQYL0DEI3KL69R6V0` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of CREDENTIAL
-- ----------------------------
INSERT INTO `CREDENTIAL` VALUES ('024b62f1-3af0-49fc-a15f-e843b72e00df', NULL, 'password', 'a5461470-33eb-4b2d-82d4-b0484e96ad7f', 1574174719522, NULL, '{\"value\":\"tfHk9estQfa27osLCY2QelpkL6Sm6rPS+iQ33ytPSD4p10Fk7ophI7ChERAnzDjVSmvdsZAttsg2Yr+8F4Gzfw==\",\"salt\":\"goh99WgI7T1ZuGdrKzNAeQ==\"}', '{\"hashIterations\":27500,\"algorithm\":\"pbkdf2-sha256\"}', 10);
INSERT INTO `CREDENTIAL` VALUES ('73c8d1ca-d548-4e1a-a82d-2c1d0d3ee017', NULL, 'password', '22a4d9fe-194c-4c6e-841a-8a55b402459f', 1580237291489, NULL, '{\"value\":\"fea4QiAzqmOctQGtJrKvoPRIUKLdQ5UKFIEPEQ7PYjTjxvucDZVk8yzXNfsDHvgpZ2rWiwsACgvsymdHnmru9w==\",\"salt\":\"nu5yJh98jz8cGLnLx36uvg==\"}', '{\"hashIterations\":27500,\"algorithm\":\"pbkdf2-sha256\"}', 10);
INSERT INTO `CREDENTIAL` VALUES ('b0ca3587-c787-48a3-a5ee-0f6d3f86e605', NULL, 'password', '42f3d5af-ed66-40d1-8b32-ae35ef9d619e', 1607909908129, NULL, '{\"value\":\"25gqulGGVrlnm99z5P36yc4urXbIrvftzfFaTEUrf3l4bRKZP0eIdNr3/UcQi+eY+SkyXIauZZUyrAuUPsqUWA==\",\"salt\":\"3ynuyxEQ025yvRHnNP/Wbw==\"}', '{\"hashIterations\":27500,\"algorithm\":\"pbkdf2-sha256\"}', 10);

-- ----------------------------
-- Table structure for DATABASECHANGELOG
-- ----------------------------
DROP TABLE IF EXISTS `DATABASECHANGELOG`;
CREATE TABLE `DATABASECHANGELOG`  (
  `ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `AUTHOR` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FILENAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DATEEXECUTED` datetime(0) NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MD5SUM` varchar(35) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `COMMENTS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `TAG` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LIQUIBASE` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CONTEXTS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LABELS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of DATABASECHANGELOG
-- ----------------------------
INSERT INTO `DATABASECHANGELOG` VALUES ('1.0.0.Final-KEYCLOAK-5461', 'sthorger@redhat.com', 'META-INF/jpa-changelog-1.0.0.Final.xml', '2020-12-14 01:30:09', 1, 'EXECUTED', '8:bda77d94bf90182a1e30c24f1c155ec7', 'createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.0.0.Final-KEYCLOAK-5461', 'sthorger@redhat.com', 'META-INF/db2-jpa-changelog-1.0.0.Final.xml', '2020-12-14 01:30:09', 2, 'MARK_RAN', '8:1ecb330f30986693d1cba9ab579fa219', 'createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.1.0.Beta1', 'sthorger@redhat.com', 'META-INF/jpa-changelog-1.1.0.Beta1.xml', '2020-12-14 01:30:22', 3, 'EXECUTED', '8:cb7ace19bc6d959f305605d255d4c843', 'delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.1.0.Final', 'sthorger@redhat.com', 'META-INF/jpa-changelog-1.1.0.Final.xml', '2020-12-14 01:30:22', 4, 'EXECUTED', '8:80230013e961310e6872e871be424a63', 'renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.2.0.Beta1', 'psilva@redhat.com', 'META-INF/jpa-changelog-1.2.0.Beta1.xml', '2020-12-14 01:30:56', 5, 'EXECUTED', '8:67f4c20929126adc0c8e9bf48279d244', 'delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.2.0.Beta1', 'psilva@redhat.com', 'META-INF/db2-jpa-changelog-1.2.0.Beta1.xml', '2020-12-14 01:30:56', 6, 'MARK_RAN', '8:7311018b0b8179ce14628ab412bb6783', 'delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.2.0.RC1', 'bburke@redhat.com', 'META-INF/jpa-changelog-1.2.0.CR1.xml', '2020-12-14 01:31:28', 7, 'EXECUTED', '8:037ba1216c3640f8785ee6b8e7c8e3c1', 'delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.2.0.RC1', 'bburke@redhat.com', 'META-INF/db2-jpa-changelog-1.2.0.CR1.xml', '2020-12-14 01:31:28', 8, 'MARK_RAN', '8:7fe6ffe4af4df289b3157de32c624263', 'delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.2.0.Final', 'keycloak', 'META-INF/jpa-changelog-1.2.0.Final.xml', '2020-12-14 01:31:28', 9, 'EXECUTED', '8:9c136bc3187083a98745c7d03bc8a303', 'update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.3.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-1.3.0.xml', '2020-12-14 01:32:03', 10, 'EXECUTED', '8:b5f09474dca81fb56a97cf5b6553d331', 'delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.4.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-1.4.0.xml', '2020-12-14 01:32:20', 11, 'EXECUTED', '8:ca924f31bd2a3b219fdcfe78c82dacf4', 'delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.4.0', 'bburke@redhat.com', 'META-INF/db2-jpa-changelog-1.4.0.xml', '2020-12-14 01:32:20', 12, 'MARK_RAN', '8:8acad7483e106416bcfa6f3b824a16cd', 'delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.5.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-1.5.0.xml', '2020-12-14 01:32:24', 13, 'EXECUTED', '8:9b1266d17f4f87c78226f5055408fd5e', 'delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.6.1_from15', 'mposolda@redhat.com', 'META-INF/jpa-changelog-1.6.1.xml', '2020-12-14 01:32:29', 14, 'EXECUTED', '8:d80ec4ab6dbfe573550ff72396c7e910', 'addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.6.1_from16-pre', 'mposolda@redhat.com', 'META-INF/jpa-changelog-1.6.1.xml', '2020-12-14 01:32:29', 15, 'MARK_RAN', '8:d86eb172171e7c20b9c849b584d147b2', 'delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.6.1_from16', 'mposolda@redhat.com', 'META-INF/jpa-changelog-1.6.1.xml', '2020-12-14 01:32:29', 16, 'MARK_RAN', '8:5735f46f0fa60689deb0ecdc2a0dea22', 'dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.6.1', 'mposolda@redhat.com', 'META-INF/jpa-changelog-1.6.1.xml', '2020-12-14 01:32:29', 17, 'EXECUTED', '8:d41d8cd98f00b204e9800998ecf8427e', 'empty', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.7.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-1.7.0.xml', '2020-12-14 01:32:51', 18, 'EXECUTED', '8:5c1a8fd2014ac7fc43b90a700f117b23', 'createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.8.0', 'mposolda@redhat.com', 'META-INF/jpa-changelog-1.8.0.xml', '2020-12-14 01:33:10', 19, 'EXECUTED', '8:1f6c2c2dfc362aff4ed75b3f0ef6b331', 'addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.8.0-2', 'keycloak', 'META-INF/jpa-changelog-1.8.0.xml', '2020-12-14 01:33:10', 20, 'EXECUTED', '8:dee9246280915712591f83a127665107', 'dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.8.0', 'mposolda@redhat.com', 'META-INF/db2-jpa-changelog-1.8.0.xml', '2020-12-14 01:33:10', 21, 'MARK_RAN', '8:9eb2ee1fa8ad1c5e426421a6f8fdfa6a', 'addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.8.0-2', 'keycloak', 'META-INF/db2-jpa-changelog-1.8.0.xml', '2020-12-14 01:33:10', 22, 'MARK_RAN', '8:dee9246280915712591f83a127665107', 'dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.9.0', 'mposolda@redhat.com', 'META-INF/jpa-changelog-1.9.0.xml', '2020-12-14 01:33:14', 23, 'EXECUTED', '8:d9fa18ffa355320395b86270680dd4fe', 'update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.9.1', 'keycloak', 'META-INF/jpa-changelog-1.9.1.xml', '2020-12-14 01:33:14', 24, 'EXECUTED', '8:90cff506fedb06141ffc1c71c4a1214c', 'modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.9.1', 'keycloak', 'META-INF/db2-jpa-changelog-1.9.1.xml', '2020-12-14 01:33:15', 25, 'MARK_RAN', '8:11a788aed4961d6d29c427c063af828c', 'modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('1.9.2', 'keycloak', 'META-INF/jpa-changelog-1.9.2.xml', '2020-12-14 01:33:20', 26, 'EXECUTED', '8:a4218e51e1faf380518cce2af5d39b43', 'createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-2.0.0', 'psilva@redhat.com', 'META-INF/jpa-changelog-authz-2.0.0.xml', '2020-12-14 01:33:50', 27, 'EXECUTED', '8:d9e9a1bfaa644da9952456050f07bbdc', 'createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-2.5.1', 'psilva@redhat.com', 'META-INF/jpa-changelog-authz-2.5.1.xml', '2020-12-14 01:33:50', 28, 'EXECUTED', '8:d1bf991a6163c0acbfe664b615314505', 'update tableName=RESOURCE_SERVER_POLICY', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.1.0-KEYCLOAK-5461', 'bburke@redhat.com', 'META-INF/jpa-changelog-2.1.0.xml', '2020-12-14 01:34:07', 29, 'EXECUTED', '8:88a743a1e87ec5e30bf603da68058a8c', 'createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.2.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-2.2.0.xml', '2020-12-14 01:34:13', 30, 'EXECUTED', '8:c5517863c875d325dea463d00ec26d7a', 'addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.3.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-2.3.0.xml', '2020-12-14 01:34:22', 31, 'EXECUTED', '8:ada8b4833b74a498f376d7136bc7d327', 'createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.4.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-2.4.0.xml', '2020-12-14 01:34:23', 32, 'EXECUTED', '8:b9b73c8ea7299457f99fcbb825c263ba', 'customChange', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.5.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-2.5.0.xml', '2020-12-14 01:34:24', 33, 'EXECUTED', '8:07724333e625ccfcfc5adc63d57314f3', 'customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.5.0-unicode-oracle', 'hmlnarik@redhat.com', 'META-INF/jpa-changelog-2.5.0.xml', '2020-12-14 01:34:24', 34, 'MARK_RAN', '8:8b6fd445958882efe55deb26fc541a7b', 'modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.5.0-unicode-other-dbs', 'hmlnarik@redhat.com', 'META-INF/jpa-changelog-2.5.0.xml', '2020-12-14 01:34:49', 35, 'EXECUTED', '8:29b29cfebfd12600897680147277a9d7', 'modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.5.0-duplicate-email-support', 'slawomir@dabek.name', 'META-INF/jpa-changelog-2.5.0.xml', '2020-12-14 01:34:50', 36, 'EXECUTED', '8:73ad77ca8fd0410c7f9f15a471fa52bc', 'addColumn tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.5.0-unique-group-names', 'hmlnarik@redhat.com', 'META-INF/jpa-changelog-2.5.0.xml', '2020-12-14 01:34:51', 37, 'EXECUTED', '8:64f27a6fdcad57f6f9153210f2ec1bdb', 'addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('2.5.1', 'bburke@redhat.com', 'META-INF/jpa-changelog-2.5.1.xml', '2020-12-14 01:34:52', 38, 'EXECUTED', '8:27180251182e6c31846c2ddab4bc5781', 'addColumn tableName=FED_USER_CONSENT', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.0.0', 'bburke@redhat.com', 'META-INF/jpa-changelog-3.0.0.xml', '2020-12-14 01:34:53', 39, 'EXECUTED', '8:d56f201bfcfa7a1413eb3e9bc02978f9', 'addColumn tableName=IDENTITY_PROVIDER', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.2.0-fix', 'keycloak', 'META-INF/jpa-changelog-3.2.0.xml', '2020-12-14 01:34:53', 40, 'MARK_RAN', '8:91f5522bf6afdc2077dfab57fbd3455c', 'addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.2.0-fix-with-keycloak-5416', 'keycloak', 'META-INF/jpa-changelog-3.2.0.xml', '2020-12-14 01:34:53', 41, 'MARK_RAN', '8:0f01b554f256c22caeb7d8aee3a1cdc8', 'dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.2.0-fix-offline-sessions', 'hmlnarik', 'META-INF/jpa-changelog-3.2.0.xml', '2020-12-14 01:34:53', 42, 'EXECUTED', '8:ab91cf9cee415867ade0e2df9651a947', 'customChange', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.2.0-fixed', 'keycloak', 'META-INF/jpa-changelog-3.2.0.xml', '2020-12-14 01:35:29', 43, 'EXECUTED', '8:ceac9b1889e97d602caf373eadb0d4b7', 'addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.3.0', 'keycloak', 'META-INF/jpa-changelog-3.3.0.xml', '2020-12-14 01:35:30', 44, 'EXECUTED', '8:84b986e628fe8f7fd8fd3c275c5259f2', 'addColumn tableName=USER_ENTITY', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-3.4.0.CR1-resource-server-pk-change-part1', 'glavoie@gmail.com', 'META-INF/jpa-changelog-authz-3.4.0.CR1.xml', '2020-12-14 01:35:33', 45, 'EXECUTED', '8:a164ae073c56ffdbc98a615493609a52', 'addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095', 'hmlnarik@redhat.com', 'META-INF/jpa-changelog-authz-3.4.0.CR1.xml', '2020-12-14 01:35:33', 46, 'EXECUTED', '8:70a2b4f1f4bd4dbf487114bdb1810e64', 'customChange', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-3.4.0.CR1-resource-server-pk-change-part3-fixed', 'glavoie@gmail.com', 'META-INF/jpa-changelog-authz-3.4.0.CR1.xml', '2020-12-14 01:35:33', 47, 'MARK_RAN', '8:7be68b71d2f5b94b8df2e824f2860fa2', 'dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex', 'glavoie@gmail.com', 'META-INF/jpa-changelog-authz-3.4.0.CR1.xml', '2020-12-14 01:35:56', 48, 'EXECUTED', '8:bab7c631093c3861d6cf6144cd944982', 'addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authn-3.4.0.CR1-refresh-token-max-reuse', 'glavoie@gmail.com', 'META-INF/jpa-changelog-authz-3.4.0.CR1.xml', '2020-12-14 01:35:58', 49, 'EXECUTED', '8:fa809ac11877d74d76fe40869916daad', 'addColumn tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.4.0', 'keycloak', 'META-INF/jpa-changelog-3.4.0.xml', '2020-12-14 01:36:17', 50, 'EXECUTED', '8:fac23540a40208f5f5e326f6ceb4d291', 'addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.4.0-KEYCLOAK-5230', 'hmlnarik@redhat.com', 'META-INF/jpa-changelog-3.4.0.xml', '2020-12-14 01:36:22', 51, 'EXECUTED', '8:2612d1b8a97e2b5588c346e817307593', 'createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.4.1', 'psilva@redhat.com', 'META-INF/jpa-changelog-3.4.1.xml', '2020-12-14 01:36:22', 52, 'EXECUTED', '8:9842f155c5db2206c88bcb5d1046e941', 'modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.4.2', 'keycloak', 'META-INF/jpa-changelog-3.4.2.xml', '2020-12-14 01:36:22', 53, 'EXECUTED', '8:2e12e06e45498406db72d5b3da5bbc76', 'update tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('3.4.2-KEYCLOAK-5172', 'mkanis@redhat.com', 'META-INF/jpa-changelog-3.4.2.xml', '2020-12-14 01:36:23', 54, 'EXECUTED', '8:33560e7c7989250c40da3abdabdc75a4', 'update tableName=CLIENT', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.0.0-KEYCLOAK-6335', 'bburke@redhat.com', 'META-INF/jpa-changelog-4.0.0.xml', '2020-12-14 01:36:24', 55, 'EXECUTED', '8:87a8d8542046817a9107c7eb9cbad1cd', 'createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.0.0-CLEANUP-UNUSED-TABLE', 'bburke@redhat.com', 'META-INF/jpa-changelog-4.0.0.xml', '2020-12-14 01:36:25', 56, 'EXECUTED', '8:3ea08490a70215ed0088c273d776311e', 'dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.0.0-KEYCLOAK-6228', 'bburke@redhat.com', 'META-INF/jpa-changelog-4.0.0.xml', '2020-12-14 01:36:33', 57, 'EXECUTED', '8:2d56697c8723d4592ab608ce14b6ed68', 'dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.0.0-KEYCLOAK-5579-fixed', 'mposolda@redhat.com', 'META-INF/jpa-changelog-4.0.0.xml', '2020-12-14 01:37:20', 58, 'EXECUTED', '8:3e423e249f6068ea2bbe48bf907f9d86', 'dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-4.0.0.CR1', 'psilva@redhat.com', 'META-INF/jpa-changelog-authz-4.0.0.CR1.xml', '2020-12-14 01:37:33', 59, 'EXECUTED', '8:15cabee5e5df0ff099510a0fc03e4103', 'createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-4.0.0.Beta3', 'psilva@redhat.com', 'META-INF/jpa-changelog-authz-4.0.0.Beta3.xml', '2020-12-14 01:37:37', 60, 'EXECUTED', '8:4b80200af916ac54d2ffbfc47918ab0e', 'addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-4.2.0.Final', 'mhajas@redhat.com', 'META-INF/jpa-changelog-authz-4.2.0.Final.xml', '2020-12-14 01:37:40', 61, 'EXECUTED', '8:66564cd5e168045d52252c5027485bbb', 'createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-4.2.0.Final-KEYCLOAK-9944', 'hmlnarik@redhat.com', 'META-INF/jpa-changelog-authz-4.2.0.Final.xml', '2020-12-14 01:37:41', 62, 'EXECUTED', '8:1c7064fafb030222be2bd16ccf690f6f', 'addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.2.0-KEYCLOAK-6313', 'wadahiro@gmail.com', 'META-INF/jpa-changelog-4.2.0.xml', '2020-12-14 01:37:42', 63, 'EXECUTED', '8:2de18a0dce10cdda5c7e65c9b719b6e5', 'addColumn tableName=REQUIRED_ACTION_PROVIDER', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.3.0-KEYCLOAK-7984', 'wadahiro@gmail.com', 'META-INF/jpa-changelog-4.3.0.xml', '2020-12-14 01:37:42', 64, 'EXECUTED', '8:03e413dd182dcbd5c57e41c34d0ef682', 'update tableName=REQUIRED_ACTION_PROVIDER', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.6.0-KEYCLOAK-7950', 'psilva@redhat.com', 'META-INF/jpa-changelog-4.6.0.xml', '2020-12-14 01:37:42', 65, 'EXECUTED', '8:d27b42bb2571c18fbe3fe4e4fb7582a7', 'update tableName=RESOURCE_SERVER_RESOURCE', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.6.0-KEYCLOAK-8377', 'keycloak', 'META-INF/jpa-changelog-4.6.0.xml', '2020-12-14 01:37:45', 66, 'EXECUTED', '8:698baf84d9fd0027e9192717c2154fb8', 'createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.6.0-KEYCLOAK-8555', 'gideonray@gmail.com', 'META-INF/jpa-changelog-4.6.0.xml', '2020-12-14 01:37:46', 67, 'EXECUTED', '8:ced8822edf0f75ef26eb51582f9a821a', 'createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.7.0-KEYCLOAK-1267', 'sguilhen@redhat.com', 'META-INF/jpa-changelog-4.7.0.xml', '2020-12-14 01:37:47', 68, 'EXECUTED', '8:f0abba004cf429e8afc43056df06487d', 'addColumn tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.7.0-KEYCLOAK-7275', 'keycloak', 'META-INF/jpa-changelog-4.7.0.xml', '2020-12-14 01:37:49', 69, 'EXECUTED', '8:6662f8b0b611caa359fcf13bf63b4e24', 'renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('4.8.0-KEYCLOAK-8835', 'sguilhen@redhat.com', 'META-INF/jpa-changelog-4.8.0.xml', '2020-12-14 01:37:51', 70, 'EXECUTED', '8:9e6b8009560f684250bdbdf97670d39e', 'addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('authz-7.0.0-KEYCLOAK-10443', 'psilva@redhat.com', 'META-INF/jpa-changelog-authz-7.0.0.xml', '2020-12-14 01:37:52', 71, 'EXECUTED', '8:4223f561f3b8dc655846562b57bb502e', 'addColumn tableName=RESOURCE_SERVER', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('8.0.0-adding-credential-columns', 'keycloak', 'META-INF/jpa-changelog-8.0.0.xml', '2020-12-14 01:37:54', 72, 'EXECUTED', '8:215a31c398b363ce383a2b301202f29e', 'addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('8.0.0-updating-credential-data-not-oracle', 'keycloak', 'META-INF/jpa-changelog-8.0.0.xml', '2020-12-14 01:37:54', 73, 'EXECUTED', '8:aa47e66c23e04356194fe287169e9c35', 'update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('8.0.0-updating-credential-data-oracle', 'keycloak', 'META-INF/jpa-changelog-8.0.0.xml', '2020-12-14 01:37:54', 74, 'MARK_RAN', '8:aa8d0292cba5b0ca2749f792784db4ce', 'update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('8.0.0-credential-cleanup-fixed', 'keycloak', 'META-INF/jpa-changelog-8.0.0.xml', '2020-12-14 01:38:08', 75, 'EXECUTED', '8:79e4fd6c6442980e58d52ffc3ee7b19c', 'dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('8.0.0-resource-tag-support', 'keycloak', 'META-INF/jpa-changelog-8.0.0.xml', '2020-12-14 01:38:10', 76, 'EXECUTED', '8:87af6a1e6d241ca4b15801d1f86a297d', 'addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.0-always-display-client', 'keycloak', 'META-INF/jpa-changelog-9.0.0.xml', '2020-12-14 01:38:10', 77, 'EXECUTED', '8:b44f8d9b7b6ea455305a6d72a200ed15', 'addColumn tableName=CLIENT', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.0-drop-constraints-for-column-increase', 'keycloak', 'META-INF/jpa-changelog-9.0.0.xml', '2020-12-14 01:38:11', 78, 'MARK_RAN', '8:2d8ed5aaaeffd0cb004c046b4a903ac5', 'dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.0-increase-column-size-federated-fk', 'keycloak', 'META-INF/jpa-changelog-9.0.0.xml', '2020-12-14 01:38:15', 79, 'EXECUTED', '8:e290c01fcbc275326c511633f6e2acde', 'modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.0-recreate-constraints-after-column-increase', 'keycloak', 'META-INF/jpa-changelog-9.0.0.xml', '2020-12-14 01:38:15', 80, 'MARK_RAN', '8:c9db8784c33cea210872ac2d805439f8', 'addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.1-add-index-to-client.client_id', 'keycloak', 'META-INF/jpa-changelog-9.0.1.xml', '2020-12-14 01:38:16', 81, 'EXECUTED', '8:95b676ce8fc546a1fcfb4c92fae4add5', 'createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.1-KEYCLOAK-12579-drop-constraints', 'keycloak', 'META-INF/jpa-changelog-9.0.1.xml', '2020-12-14 01:38:16', 82, 'MARK_RAN', '8:38a6b2a41f5651018b1aca93a41401e5', 'dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.1-KEYCLOAK-12579-add-not-null-constraint', 'keycloak', 'META-INF/jpa-changelog-9.0.1.xml', '2020-12-14 01:38:17', 83, 'EXECUTED', '8:3fb99bcad86a0229783123ac52f7609c', 'addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.1-KEYCLOAK-12579-recreate-constraints', 'keycloak', 'META-INF/jpa-changelog-9.0.1.xml', '2020-12-14 01:38:17', 84, 'MARK_RAN', '8:64f27a6fdcad57f6f9153210f2ec1bdb', 'addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('9.0.1-add-index-to-events', 'keycloak', 'META-INF/jpa-changelog-9.0.1.xml', '2020-12-14 01:38:17', 85, 'EXECUTED', '8:ab4f863f39adafd4c862f7ec01890abc', 'createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY', '', NULL, '3.8.8', NULL, NULL, '7909329662');
INSERT INTO `DATABASECHANGELOG` VALUES ('map-remove-ri', 'keycloak', 'META-INF/jpa-changelog-11.0.0.xml', '2020-12-14 01:38:18', 86, 'EXECUTED', '8:13c419a0eb336e91ee3a3bf8fda6e2a7', 'dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9', '', NULL, '3.8.8', NULL, NULL, '7909329662');

-- ----------------------------
-- Table structure for DATABASECHANGELOGLOCK
-- ----------------------------
DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
CREATE TABLE `DATABASECHANGELOGLOCK`  (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime(0) NULL DEFAULT NULL,
  `LOCKEDBY` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of DATABASECHANGELOGLOCK
-- ----------------------------
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1, b'0', NULL, NULL);
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1000, b'0', NULL, NULL);
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1001, b'0', NULL, NULL);

-- ----------------------------
-- Table structure for DEFAULT_CLIENT_SCOPE
-- ----------------------------
DROP TABLE IF EXISTS `DEFAULT_CLIENT_SCOPE`;
CREATE TABLE `DEFAULT_CLIENT_SCOPE`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DEFAULT_SCOPE` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`REALM_ID`, `SCOPE_ID`) USING BTREE,
  INDEX `IDX_DEFCLS_REALM`(`REALM_ID`) USING BTREE,
  INDEX `IDX_DEFCLS_SCOPE`(`SCOPE_ID`) USING BTREE,
  CONSTRAINT `FK_R_DEF_CLI_SCOPE_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_R_DEF_CLI_SCOPE_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of DEFAULT_CLIENT_SCOPE
-- ----------------------------
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', '18e141bf-dabe-4858-879c-dbc439cdead4', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', '51d49314-b511-43e0-9258-bfb873758a78', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', '569b3d44-4ecd-4768-a58c-70ff38f4b4fe', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', '77c7e29d-1a22-4419-bbfb-4a62bb033449', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', 'a3e7b19d-df6c-437e-9eea-06fec1becb2f', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', 'b3526ac1-10e2-4344-8621-9c5a0853e97a', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('baeldung', 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', '0c3005e6-8f78-4da7-b654-73643ab087d8', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', '4308b568-d494-4a27-bcbb-44f510348cee', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', '6ea576db-f1ca-421d-b96b-1b08cf69131d', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', '7003f9b2-6302-4e25-9e06-2aff252a9612', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', '84a20307-7989-4455-9a8f-b338704a2f2b', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', '89860f9b-8982-4ded-a6a0-b7f75a8447e6', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', 'd0359686-f867-4687-a7f1-1fe43386e1ed', b'0');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', 'd7f50591-889b-4f3a-9e2b-dc16e253b133', b'1');
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('master', 'e5510191-5adb-483f-ad0a-eb363f0a75b7', b'0');

-- ----------------------------
-- Table structure for EVENT_ENTITY
-- ----------------------------
DROP TABLE IF EXISTS `EVENT_ENTITY`;
CREATE TABLE `EVENT_ENTITY`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DETAILS_JSON` varchar(2550) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ERROR` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `IP_ADDRESS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `SESSION_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `EVENT_TIME` bigint(20) NULL DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_EVENT_TIME`(`REALM_ID`, `EVENT_TIME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of EVENT_ENTITY
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_ATTRIBUTE
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_ATTRIBUTE`;
CREATE TABLE `FED_USER_ATTRIBUTE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `VALUE` varchar(2024) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_FU_ATTRIBUTE`(`USER_ID`, `REALM_ID`, `NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_ATTRIBUTE
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_CONSENT
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_CONSENT`;
CREATE TABLE `FED_USER_CONSENT`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CREATED_DATE` bigint(20) NULL DEFAULT NULL,
  `LAST_UPDATED_DATE` bigint(20) NULL DEFAULT NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `EXTERNAL_CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_FU_CONSENT`(`USER_ID`, `CLIENT_ID`) USING BTREE,
  INDEX `IDX_FU_CONSENT_RU`(`REALM_ID`, `USER_ID`) USING BTREE,
  INDEX `IDX_FU_CNSNT_EXT`(`USER_ID`, `CLIENT_STORAGE_PROVIDER`, `EXTERNAL_CLIENT_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_CONSENT
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_CONSENT_CL_SCOPE
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_CONSENT_CL_SCOPE`;
CREATE TABLE `FED_USER_CONSENT_CL_SCOPE`  (
  `USER_CONSENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`USER_CONSENT_ID`, `SCOPE_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_CONSENT_CL_SCOPE
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_CREDENTIAL
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_CREDENTIAL`;
CREATE TABLE `FED_USER_CREDENTIAL`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SALT` tinyblob NULL,
  `TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CREATED_DATE` bigint(20) NULL DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USER_LABEL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `SECRET_DATA` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `CREDENTIAL_DATA` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `PRIORITY` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_FU_CREDENTIAL`(`USER_ID`, `TYPE`) USING BTREE,
  INDEX `IDX_FU_CREDENTIAL_RU`(`REALM_ID`, `USER_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_CREDENTIAL
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_GROUP_MEMBERSHIP
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_GROUP_MEMBERSHIP`;
CREATE TABLE `FED_USER_GROUP_MEMBERSHIP`  (
  `GROUP_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`, `USER_ID`) USING BTREE,
  INDEX `IDX_FU_GROUP_MEMBERSHIP`(`USER_ID`, `GROUP_ID`) USING BTREE,
  INDEX `IDX_FU_GROUP_MEMBERSHIP_RU`(`REALM_ID`, `USER_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_GROUP_MEMBERSHIP
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_REQUIRED_ACTION
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_REQUIRED_ACTION`;
CREATE TABLE `FED_USER_REQUIRED_ACTION`  (
  `REQUIRED_ACTION` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT ' ',
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`REQUIRED_ACTION`, `USER_ID`) USING BTREE,
  INDEX `IDX_FU_REQUIRED_ACTION`(`USER_ID`, `REQUIRED_ACTION`) USING BTREE,
  INDEX `IDX_FU_REQUIRED_ACTION_RU`(`REALM_ID`, `USER_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_REQUIRED_ACTION
-- ----------------------------

-- ----------------------------
-- Table structure for FED_USER_ROLE_MAPPING
-- ----------------------------
DROP TABLE IF EXISTS `FED_USER_ROLE_MAPPING`;
CREATE TABLE `FED_USER_ROLE_MAPPING`  (
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ROLE_ID`, `USER_ID`) USING BTREE,
  INDEX `IDX_FU_ROLE_MAPPING`(`USER_ID`, `ROLE_ID`) USING BTREE,
  INDEX `IDX_FU_ROLE_MAPPING_RU`(`REALM_ID`, `USER_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FED_USER_ROLE_MAPPING
-- ----------------------------

-- ----------------------------
-- Table structure for FEDERATED_IDENTITY
-- ----------------------------
DROP TABLE IF EXISTS `FEDERATED_IDENTITY`;
CREATE TABLE `FEDERATED_IDENTITY`  (
  `IDENTITY_PROVIDER` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `FEDERATED_USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `FEDERATED_USERNAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `TOKEN` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`, `USER_ID`) USING BTREE,
  INDEX `IDX_FEDIDENTITY_USER`(`USER_ID`) USING BTREE,
  INDEX `IDX_FEDIDENTITY_FEDUSER`(`FEDERATED_USER_ID`) USING BTREE,
  CONSTRAINT `FK404288B92EF007A6` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FEDERATED_IDENTITY
-- ----------------------------

-- ----------------------------
-- Table structure for FEDERATED_USER
-- ----------------------------
DROP TABLE IF EXISTS `FEDERATED_USER`;
CREATE TABLE `FEDERATED_USER`  (
  `ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of FEDERATED_USER
-- ----------------------------

-- ----------------------------
-- Table structure for GROUP_ATTRIBUTE
-- ----------------------------
DROP TABLE IF EXISTS `GROUP_ATTRIBUTE`;
CREATE TABLE `GROUP_ATTRIBUTE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `GROUP_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_GROUP_ATTR_GROUP`(`GROUP_ID`) USING BTREE,
  CONSTRAINT `FK_GROUP_ATTRIBUTE_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of GROUP_ATTRIBUTE
-- ----------------------------

-- ----------------------------
-- Table structure for GROUP_ROLE_MAPPING
-- ----------------------------
DROP TABLE IF EXISTS `GROUP_ROLE_MAPPING`;
CREATE TABLE `GROUP_ROLE_MAPPING`  (
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `GROUP_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ROLE_ID`, `GROUP_ID`) USING BTREE,
  INDEX `IDX_GROUP_ROLE_MAPP_GROUP`(`GROUP_ID`) USING BTREE,
  CONSTRAINT `FK_GROUP_ROLE_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_GROUP_ROLE_ROLE` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of GROUP_ROLE_MAPPING
-- ----------------------------

-- ----------------------------
-- Table structure for IDENTITY_PROVIDER
-- ----------------------------
DROP TABLE IF EXISTS `IDENTITY_PROVIDER`;
CREATE TABLE `IDENTITY_PROVIDER`  (
  `INTERNAL_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `PROVIDER_ALIAS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PROVIDER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `STORE_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  `AUTHENTICATE_BY_DEFAULT` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ADD_TOKEN_ROLE` bit(1) NOT NULL DEFAULT b'1',
  `TRUST_EMAIL` bit(1) NOT NULL DEFAULT b'0',
  `FIRST_BROKER_LOGIN_FLOW_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `POST_BROKER_LOGIN_FLOW_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PROVIDER_DISPLAY_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LINK_ONLY` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`INTERNAL_ID`) USING BTREE,
  UNIQUE INDEX `UK_2DAELWNIBJI49AVXSRTUF6XJ33`(`PROVIDER_ALIAS`, `REALM_ID`) USING BTREE,
  INDEX `IDX_IDENT_PROV_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK2B4EBC52AE5C3B34` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of IDENTITY_PROVIDER
-- ----------------------------

-- ----------------------------
-- Table structure for IDENTITY_PROVIDER_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `IDENTITY_PROVIDER_CONFIG`;
CREATE TABLE `IDENTITY_PROVIDER_CONFIG`  (
  `IDENTITY_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FKDC4897CF864C4E43` FOREIGN KEY (`IDENTITY_PROVIDER_ID`) REFERENCES `IDENTITY_PROVIDER` (`INTERNAL_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of IDENTITY_PROVIDER_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for IDENTITY_PROVIDER_MAPPER
-- ----------------------------
DROP TABLE IF EXISTS `IDENTITY_PROVIDER_MAPPER`;
CREATE TABLE `IDENTITY_PROVIDER_MAPPER`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `IDP_ALIAS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `IDP_MAPPER_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_ID_PROV_MAPP_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_IDPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of IDENTITY_PROVIDER_MAPPER
-- ----------------------------

-- ----------------------------
-- Table structure for IDP_MAPPER_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `IDP_MAPPER_CONFIG`;
CREATE TABLE `IDP_MAPPER_CONFIG`  (
  `IDP_MAPPER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`IDP_MAPPER_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK_IDPMCONFIG` FOREIGN KEY (`IDP_MAPPER_ID`) REFERENCES `IDENTITY_PROVIDER_MAPPER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of IDP_MAPPER_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for KEYCLOAK_GROUP
-- ----------------------------
DROP TABLE IF EXISTS `KEYCLOAK_GROUP`;
CREATE TABLE `KEYCLOAK_GROUP`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `PARENT_GROUP` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `SIBLING_NAMES`(`REALM_ID`, `PARENT_GROUP`, `NAME`) USING BTREE,
  CONSTRAINT `FK_GROUP_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of KEYCLOAK_GROUP
-- ----------------------------

-- ----------------------------
-- Table structure for KEYCLOAK_ROLE
-- ----------------------------
DROP TABLE IF EXISTS `KEYCLOAK_ROLE`;
CREATE TABLE `KEYCLOAK_ROLE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_REALM_CONSTRAINT` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CLIENT_ROLE` bit(1) NULL DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CLIENT` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_J3RWUVD56ONTGSUHOGM184WW2-2`(`NAME`, `CLIENT_REALM_CONSTRAINT`) USING BTREE,
  INDEX `IDX_KEYCLOAK_ROLE_CLIENT`(`CLIENT`) USING BTREE,
  INDEX `IDX_KEYCLOAK_ROLE_REALM`(`REALM`) USING BTREE,
  CONSTRAINT `FK_6VYQFE4CN4WLQ8R6KT5VDSJ5C` FOREIGN KEY (`REALM`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of KEYCLOAK_ROLE
-- ----------------------------
INSERT INTO `KEYCLOAK_ROLE` VALUES ('0332e99b-3dfc-4193-9e13-5728f8f3e6d6', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_impersonation}', 'impersonation', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('03b26584-c1d4-460d-b9f1-adbe2573b30e', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_view-events}', 'view-events', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('0dd6a8c7-d669-4941-9ea1-521980e9c53f', 'baeldung', b'0', '${role_uma_authorization}', 'uma_authorization', 'baeldung', NULL, 'baeldung');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('0f8e5ee8-b014-4b7c-9b69-50f46abcba5f', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_query-groups}', 'query-groups', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('157cecb7-fd8e-47e6-b974-4a5a634da92c', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_manage-realm}', 'manage-realm', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('201aa378-e0d1-4b03-84af-f0037a8eb134', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_create-client}', 'create-client', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('29c66503-2c2e-4bad-a765-78941959694e', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_query-users}', 'query-users', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('34f6853d-2c63-429f-a854-7d69f598fcb3', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_impersonation}', 'impersonation', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('387418b1-4f80-4b00-b9dd-805ca041f805', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_view-identity-providers}', 'view-identity-providers', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('397b5703-4c81-48fd-a24c-a7e8177ef657', '4b9609f0-48d1-4e71-9381-2ecec08616f9', b'1', '${role_read-token}', 'read-token', 'baeldung', '4b9609f0-48d1-4e71-9381-2ecec08616f9', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('3ad25249-37a5-45a9-b078-c6564a72cd96', 'master', b'0', '${role_uma_authorization}', 'uma_authorization', 'master', NULL, 'master');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('3b6109f5-6e5a-4578-83c3-791ec3e2bf9e', 'baeldung', b'0', '${role_offline-access}', 'offline_access', 'baeldung', NULL, 'baeldung');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('3ea43b64-316f-4693-8346-9ee78b24adaf', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_manage-identity-providers}', 'manage-identity-providers', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('427c27d4-521a-464b-a0df-16d7f537e8d5', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_realm-admin}', 'realm-admin', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('454e77e7-3078-4408-a440-c762f95e09bf', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_manage-authorization}', 'manage-authorization', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('49735614-96ec-49b2-98fe-3af9bcd1a33a', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_create-client}', 'create-client', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('50831bfa-1251-49f9-b213-71bea42201d3', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_view-clients}', 'view-clients', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('581d71d9-85ff-4172-806f-f3c3f3f1afba', 'b77e3260-787b-4d35-8118-cf686e6f02fa', b'1', '${role_read-token}', 'read-token', 'master', 'b77e3260-787b-4d35-8118-cf686e6f02fa', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('5d00243f-ceec-4b0c-995e-d86d5b8a0ae6', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_view-clients}', 'view-clients', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('5d48274c-bd6b-4c26-ad54-f1a2254beac0', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_view-realm}', 'view-realm', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('5dc206f4-98ce-4dec-a2b9-c3a92db168ed', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_view-users}', 'view-users', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('5ea9810d-63cc-4277-9b32-ba8a3d3c6091', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_manage-realm}', 'manage-realm', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('5f7bd5a2-cbb6-4d4f-8682-7dde4b1b6462', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_view-realm}', 'view-realm', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('6eedf2b7-50ef-4495-a89b-54aef751b7fa', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_manage-authorization}', 'manage-authorization', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('74a9ebdd-c052-4e5b-a77a-b9ae3f61c312', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_create-client}', 'create-client', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('7b788da9-b489-4194-baee-9c9b9734e35c', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_query-groups}', 'query-groups', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('7ddc5c9d-3866-48c8-b40d-5c1437ef69cd', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_query-clients}', 'query-clients', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('842f6725-b2f8-4466-b68d-cc21dd79f8b3', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_view-identity-providers}', 'view-identity-providers', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('8b7b0dd8-350b-473e-b8cd-8acad34f1358', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_query-clients}', 'query-clients', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('8daa8096-d14e-4d1c-ad1f-83f822016aa1', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', '${role_manage-account}', 'manage-account', 'baeldung', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('8fb2a38f-8d10-4d8c-b08a-8d3c1a2f1f03', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', '${role_view-consent}', 'view-consent', 'baeldung', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('911b1489-9383-4734-b134-bf49bf992ce9', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_manage-clients}', 'manage-clients', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('941612de-bd85-47a5-8dfa-37c270dde28c', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_view-authorization}', 'view-authorization', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('948269c7-a69c-4c82-a7f3-88868713dfd9', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', '${role_manage-account-links}', 'manage-account-links', 'baeldung', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('9931cf33-5ccd-4758-bac4-6c6f948e1208', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_view-realm}', 'view-realm', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('9ba11c9d-1495-473e-afd8-ae12a6e06942', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_view-clients}', 'view-clients', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('a29eabe9-ae8a-442d-af22-05d79b7fcf89', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_query-realms}', 'query-realms', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('a2ec3e99-c78c-44f5-98d7-75c3a26a68cc', 'master', b'0', '${role_offline-access}', 'offline_access', 'master', NULL, 'master');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('a3cdd917-d29b-409d-90a5-99f2575aee41', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', '${role_manage-account-links}', 'manage-account-links', 'master', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('a574cf01-03e4-4573-ab9e-276d13a1ce8d', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_query-users}', 'query-users', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('a905df72-2c7c-4197-a835-c8d67a5a6a6b', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', '${role_view-applications}', 'view-applications', 'baeldung', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('a9064aa3-693c-4c68-8538-8e7bd8bddf9f', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_manage-identity-providers}', 'manage-identity-providers', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('aac3def5-f193-4a6c-9065-1667a0746a8a', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_manage-events}', 'manage-events', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('ab756dee-ebb4-4c4b-aa1c-c4748893ba8c', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', '${role_manage-consent}', 'manage-consent', 'baeldung', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', 'master', b'0', '${role_admin}', 'admin', 'master', NULL, 'master');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('abd59d44-a1aa-4f80-a8d3-2f8219f320ec', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', '${role_view-consent}', 'view-consent', 'master', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('ae28ef63-cb12-4a38-94bc-789e5b91e637', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_view-identity-providers}', 'view-identity-providers', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('aed18201-2433-4998-8fa3-0979b0b31c10', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', b'1', '${role_view-profile}', 'view-profile', 'baeldung', '12eebf0b-a3eb-49f8-9ecf-173cf8a00145', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('b2d774c2-fd76-4c13-9715-1f23355214ff', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_query-realms}', 'query-realms', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('b6054436-0871-4ffb-b03d-208237b30035', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_manage-users}', 'manage-users', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('b66a775d-c41c-4c16-87d0-07a4a343241f', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_view-authorization}', 'view-authorization', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('b690cb9c-0f4a-4be5-ade0-b40443d8149d', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_view-events}', 'view-events', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('bc78f00d-e105-40df-a689-b7357ed3a3b7', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_view-users}', 'view-users', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('bda0bf27-5fc7-4417-9013-3af6b9c1e216', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_manage-users}', 'manage-users', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c21bc3cb-33fc-4bf3-9b91-b8f270823f3c', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', '${role_view-applications}', 'view-applications', 'master', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c2de88cd-4d5a-41ef-9b1b-2a72e36fc97e', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_manage-identity-providers}', 'manage-identity-providers', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c3a253a8-a1b6-4d38-9677-f728f32482ad', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_query-realms}', 'query-realms', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c49b7f4e-a062-4fb8-a222-c5608b7263b8', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_manage-events}', 'manage-events', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c55d3dff-aee0-46ca-a1c8-e5a759694f5a', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_manage-events}', 'manage-events', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c58d42a7-515c-405e-8993-0d5ef6ab8d7f', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', '${role_manage-consent}', 'manage-consent', 'master', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c66c0d31-77b1-4e94-9da2-f8049cf9736d', 'master', b'0', '${role_create-realm}', 'create-realm', 'master', NULL, 'master');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('c7692f82-11da-4bc1-adb0-acc34fce0a4d', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_manage-authorization}', 'manage-authorization', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('ca962095-7f9b-49e2-a190-e391a0d4b704', 'baeldung', b'0', NULL, 'user', 'baeldung', NULL, 'baeldung');
INSERT INTO `KEYCLOAK_ROLE` VALUES ('cba59569-8855-472e-8be7-ac92caa24013', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_query-clients}', 'query-clients', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('cfb69f93-bbe2-48c2-b903-5cb16d1abf5c', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', '${role_view-profile}', 'view-profile', 'master', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('d3cad871-4b66-4016-b662-72446741e63d', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', b'1', '${role_manage-account}', 'manage-account', 'master', '5a7bec73-8335-42b1-a91f-18c84f7c9e85', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('d908a88f-863e-4937-a460-78fee0df71f9', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_query-groups}', 'query-groups', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('e295c16e-3560-4e37-99aa-da5a7407fce2', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_view-events}', 'view-events', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('e8f8c3cc-0ff1-4f72-a271-db6821a3cdb6', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_manage-users}', 'manage-users', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('eb14e8e5-6236-4888-b146-fcd810569ef7', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_manage-realm}', 'manage-realm', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('ecd130aa-767a-4684-85f8-3e0d1d6829b0', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_view-authorization}', 'view-authorization', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('ee1ca19e-ca29-424c-898f-47accb0f64d9', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_impersonation}', 'impersonation', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('f2c4fe67-9edd-4bef-b08c-9aab1c4f1834', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_query-users}', 'query-users', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('f389fc9f-3e07-4347-ac1a-15a090980a9d', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', b'1', '${role_manage-clients}', 'manage-clients', 'master', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('f3cb93da-273e-419a-b2f4-93f09896abcf', '6a4bfbd0-576d-4778-af56-56f876647355', b'1', '${role_view-users}', 'view-users', 'baeldung', '6a4bfbd0-576d-4778-af56-56f876647355', NULL);
INSERT INTO `KEYCLOAK_ROLE` VALUES ('fa905288-27f5-4231-8f95-8dde7d1f1ed8', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', b'1', '${role_manage-clients}', 'manage-clients', 'master', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', NULL);

-- ----------------------------
-- Table structure for MIGRATION_MODEL
-- ----------------------------
DROP TABLE IF EXISTS `MIGRATION_MODEL`;
CREATE TABLE `MIGRATION_MODEL`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VERSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `UPDATE_TIME` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_UPDATE_TIME`(`UPDATE_TIME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of MIGRATION_MODEL
-- ----------------------------
INSERT INTO `MIGRATION_MODEL` VALUES ('ohnhb', '11.0.2', 1607909900);

-- ----------------------------
-- Table structure for OFFLINE_CLIENT_SESSION
-- ----------------------------
DROP TABLE IF EXISTS `OFFLINE_CLIENT_SESSION`;
CREATE TABLE `OFFLINE_CLIENT_SESSION`  (
  `USER_SESSION_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `OFFLINE_FLAG` varchar(4) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TIMESTAMP` int(11) NULL DEFAULT NULL,
  `DATA` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'local',
  `EXTERNAL_CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'local',
  PRIMARY KEY (`USER_SESSION_ID`, `CLIENT_ID`, `CLIENT_STORAGE_PROVIDER`, `EXTERNAL_CLIENT_ID`, `OFFLINE_FLAG`) USING BTREE,
  INDEX `IDX_US_SESS_ID_ON_CL_SESS`(`USER_SESSION_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of OFFLINE_CLIENT_SESSION
-- ----------------------------

-- ----------------------------
-- Table structure for OFFLINE_USER_SESSION
-- ----------------------------
DROP TABLE IF EXISTS `OFFLINE_USER_SESSION`;
CREATE TABLE `OFFLINE_USER_SESSION`  (
  `USER_SESSION_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CREATED_ON` int(11) NOT NULL,
  `OFFLINE_FLAG` varchar(4) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DATA` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `LAST_SESSION_REFRESH` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`USER_SESSION_ID`, `OFFLINE_FLAG`) USING BTREE,
  INDEX `IDX_OFFLINE_USS_CREATEDON`(`CREATED_ON`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of OFFLINE_USER_SESSION
-- ----------------------------

-- ----------------------------
-- Table structure for POLICY_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `POLICY_CONFIG`;
CREATE TABLE `POLICY_CONFIG`  (
  `POLICY_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`POLICY_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FKDC34197CF864C4E43` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of POLICY_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for PROTOCOL_MAPPER
-- ----------------------------
DROP TABLE IF EXISTS `PROTOCOL_MAPPER`;
CREATE TABLE `PROTOCOL_MAPPER`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PROTOCOL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PROTOCOL_MAPPER_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CLIENT_SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_PROTOCOL_MAPPER_CLIENT`(`CLIENT_ID`) USING BTREE,
  INDEX `IDX_CLSCOPE_PROTMAP`(`CLIENT_SCOPE_ID`) USING BTREE,
  CONSTRAINT `FK_CLI_SCOPE_MAPPER` FOREIGN KEY (`CLIENT_SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_PCM_REALM` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of PROTOCOL_MAPPER
-- ----------------------------
INSERT INTO `PROTOCOL_MAPPER` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'birthdate', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'groups', 'openid-connect', 'oidc-usermodel-realm-role-mapper', NULL, 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'email', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, '4308b568-d494-4a27-bcbb-44f510348cee');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'profile', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('0dd15978-2780-40e6-90a7-f353386e6a18', 'audience resolve', 'openid-connect', 'oidc-audience-resolve-mapper', '7c986895-caa4-40ef-b936-0e2bfddf200a', NULL);
INSERT INTO `PROTOCOL_MAPPER` VALUES ('10cbe37f-0198-4d65-bc8a-bfe5ad8145d1', 'role list', 'saml', 'saml-role-list-mapper', NULL, '18e141bf-dabe-4858-879c-dbc439cdead4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('24924d8d-6071-4a93-b40f-326176cb335e', 'realm roles', 'openid-connect', 'oidc-usermodel-realm-role-mapper', NULL, '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'phone number', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'a3e7b19d-df6c-437e-9eea-06fec1becb2f');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'website', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('2b384cd0-9e85-4a87-8eeb-2b480b0587b7', 'allowed web origins', 'openid-connect', 'oidc-allowed-origins-mapper', NULL, '51d49314-b511-43e0-9258-bfb873758a78');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('2f6a9bdf-3758-484c-996d-e4f93555559f', 'audience resolve', 'openid-connect', 'oidc-audience-resolve-mapper', NULL, '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'username', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'locale', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'birthdate', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'phone number verified', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'd0359686-f867-4687-a7f1-1fe43386e1ed');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'picture', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'website', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'address', 'openid-connect', 'oidc-address-mapper', NULL, 'e5510191-5adb-483f-ad0a-eb363f0a75b7');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'given name', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'gender', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('44563cb5-00b5-4dc9-ac86-ff8219159eaf', 'allowed web origins', 'openid-connect', 'oidc-allowed-origins-mapper', NULL, '0c3005e6-8f78-4da7-b654-73643ab087d8');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'locale', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'given name', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'picture', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'upn', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, '6ea576db-f1ca-421d-b96b-1b08cf69131d');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'updated at', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'nickname', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('6e83b0fc-cace-49df-bd2c-29876ad9f0ec', 'client roles', 'openid-connect', 'oidc-usermodel-client-role-mapper', NULL, 'd7f50591-889b-4f3a-9e2b-dc16e253b133');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'username', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'phone number verified', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'a3e7b19d-df6c-437e-9eea-06fec1becb2f');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'zoneinfo', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'phone number', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'd0359686-f867-4687-a7f1-1fe43386e1ed');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('7ce7656b-8251-4735-b14a-d380a329da26', 'role list', 'saml', 'saml-role-list-mapper', NULL, '89860f9b-8982-4ded-a6a0-b7f75a8447e6');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('804d4798-d9a3-4fd3-8b28-d12142e8cb3d', 'client roles', 'openid-connect', 'oidc-usermodel-client-role-mapper', NULL, '111ed87a-5fd3-4cee-96df-8dbfb88cfdc0');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'family name', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'family name', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'middle name', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('90a17f10-a4d7-447d-83ae-bcbc0e9f556c', 'realm roles', 'openid-connect', 'oidc-usermodel-realm-role-mapper', NULL, 'd7f50591-889b-4f3a-9e2b-dc16e253b133');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'address', 'openid-connect', 'oidc-address-mapper', NULL, '77c7e29d-1a22-4419-bbfb-4a62bb033449');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'upn', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, 'c658ae14-e96a-4745-b21b-2ed5c4c63f5f');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('96289563-0518-4f46-8df4-2d34468d859b', 'audience resolve', 'openid-connect', 'oidc-audience-resolve-mapper', '578fe0dc-91f8-474f-a447-a20a9564d890', NULL);
INSERT INTO `PROTOCOL_MAPPER` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'locale', 'openid-connect', 'oidc-usermodel-attribute-mapper', '8e358d2f-b085-4243-8e6e-c175431e5eeb', NULL);
INSERT INTO `PROTOCOL_MAPPER` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'profile', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'email verified', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, '4308b568-d494-4a27-bcbb-44f510348cee');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'updated at', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'middle name', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'zoneinfo', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'email verified', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, 'b3526ac1-10e2-4344-8621-9c5a0853e97a');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('d3b25485-4042-419d-afff-cfd63a76e229', 'full name', 'openid-connect', 'oidc-full-name-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'locale', 'openid-connect', 'oidc-usermodel-attribute-mapper', 'aaf12708-e1b3-43ea-a94c-3d4151beced2', NULL);
INSERT INTO `PROTOCOL_MAPPER` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'gender', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('df4cece1-5f85-4195-b049-c3c42a8cf909', 'audience resolve', 'openid-connect', 'oidc-audience-resolve-mapper', NULL, 'd7f50591-889b-4f3a-9e2b-dc16e253b133');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('ee463426-41b6-4642-bd5f-7cc6b0b85663', 'full name', 'openid-connect', 'oidc-full-name-mapper', NULL, '84a20307-7989-4455-9a8f-b338704a2f2b');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'email', 'openid-connect', 'oidc-usermodel-property-mapper', NULL, 'b3526ac1-10e2-4344-8621-9c5a0853e97a');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'groups', 'openid-connect', 'oidc-usermodel-realm-role-mapper', NULL, '6ea576db-f1ca-421d-b96b-1b08cf69131d');
INSERT INTO `PROTOCOL_MAPPER` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'nickname', 'openid-connect', 'oidc-usermodel-attribute-mapper', NULL, 'ba8c9950-fd0b-4434-8be6-b58456d7b6d4');

-- ----------------------------
-- Table structure for PROTOCOL_MAPPER_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `PROTOCOL_MAPPER_CONFIG`;
CREATE TABLE `PROTOCOL_MAPPER_CONFIG`  (
  `PROTOCOL_MAPPER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`PROTOCOL_MAPPER_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK_PMCONFIG` FOREIGN KEY (`PROTOCOL_MAPPER_ID`) REFERENCES `PROTOCOL_MAPPER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of PROTOCOL_MAPPER_CONFIG
-- ----------------------------
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'birthdate', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'birthdate', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('016bc490-ae14-4628-ab0d-6df6161a07e3', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'groups', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'true', 'multivalued');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'foo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('07b8550c-b298-4cce-9ffb-900182575b76', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'email', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'email', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a7852d6-2550-4c9b-b519-cd763567153b', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'profile', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'profile', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('0a9ddd71-309c-40f0-8ea6-a0791070c6ed', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('10cbe37f-0198-4d65-bc8a-bfe5ad8145d1', 'Role', 'attribute.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('10cbe37f-0198-4d65-bc8a-bfe5ad8145d1', 'Basic', 'attribute.nameformat');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('10cbe37f-0198-4d65-bc8a-bfe5ad8145d1', 'false', 'single');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24924d8d-6071-4a93-b40f-326176cb335e', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24924d8d-6071-4a93-b40f-326176cb335e', 'realm_access.roles', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24924d8d-6071-4a93-b40f-326176cb335e', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24924d8d-6071-4a93-b40f-326176cb335e', 'true', 'multivalued');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24924d8d-6071-4a93-b40f-326176cb335e', 'foo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'phone_number', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'phoneNumber', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('24b42c6d-a93c-4aa1-9a03-2a2b55954c13', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'website', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'website', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('26dab29b-0d5a-4db7-97ef-470f04161356', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'preferred_username', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'username', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('34775747-ba71-4704-9103-f03734011fa6', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'locale', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'locale', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3a70c2d8-e45c-4896-b2d7-eccfca6af8c6', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'birthdate', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'birthdate', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3b985202-af8a-42f1-ac5f-0966a404f5d7', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'phone_number_verified', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'boolean', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'phoneNumberVerified', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d6d6270-0140-4e1f-b31f-c3aea3cd3958', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'picture', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'picture', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3d946558-affa-4d63-b118-7eadab7f3c8a', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'website', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'website', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f2863c1-d98d-45b5-b08f-af9c4d9c10f8', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'country', 'user.attribute.country');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'formatted', 'user.attribute.formatted');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'locality', 'user.attribute.locality');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'postal_code', 'user.attribute.postal_code');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'region', 'user.attribute.region');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'street', 'user.attribute.street');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('3f68c61b-34fc-4743-82db-392ce61f5916', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'given_name', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'firstName', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('422cfa5a-f2f4-4f36-82df-91b47ae1ea50', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'gender', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'gender', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('423be2cd-42c0-462e-9030-18f9b28ff2d3', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'locale', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'locale', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('4d8bc82a-eaeb-499e-8eb2-0f1dcbe91699', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'given_name', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'firstName', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('51791da9-2237-4e4a-bc4f-05c70dc98863', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'picture', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'picture', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('53eb9006-4b81-474a-8b60-80f775d54b63', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'upn', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'username', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('58d62d40-b964-4c39-9bcd-185d99578ae6', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'updated_at', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'updatedAt', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('5e5c690c-93cf-489d-a054-b109eab8911b', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'nickname', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'nickname', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('696d1670-238f-40ea-906b-c92db9ec735f', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6e83b0fc-cace-49df-bd2c-29876ad9f0ec', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6e83b0fc-cace-49df-bd2c-29876ad9f0ec', 'resource_access.${client_id}.roles', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6e83b0fc-cace-49df-bd2c-29876ad9f0ec', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6e83b0fc-cace-49df-bd2c-29876ad9f0ec', 'true', 'multivalued');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6e83b0fc-cace-49df-bd2c-29876ad9f0ec', 'foo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'preferred_username', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'username', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('6eafd1b3-7121-4919-ad1e-039fa58acc32', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'phone_number_verified', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'boolean', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'phoneNumberVerified', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('72a070f7-4363-4c88-8153-6fd2d12b9b04', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'zoneinfo', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'zoneinfo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('73cba925-8c31-443f-9601-b1514e6396c1', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'phone_number', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'phoneNumber', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('78094910-2237-4585-9a6d-f33353860448', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('7ce7656b-8251-4735-b14a-d380a329da26', 'Role', 'attribute.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('7ce7656b-8251-4735-b14a-d380a329da26', 'Basic', 'attribute.nameformat');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('7ce7656b-8251-4735-b14a-d380a329da26', 'false', 'single');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('804d4798-d9a3-4fd3-8b28-d12142e8cb3d', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('804d4798-d9a3-4fd3-8b28-d12142e8cb3d', 'resource_access.${client_id}.roles', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('804d4798-d9a3-4fd3-8b28-d12142e8cb3d', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('804d4798-d9a3-4fd3-8b28-d12142e8cb3d', 'true', 'multivalued');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('804d4798-d9a3-4fd3-8b28-d12142e8cb3d', 'foo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'family_name', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'lastName', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8a28f7dd-5ee8-4b2e-9292-14759ce44804', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'family_name', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'lastName', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8dbed80a-d672-4185-8dda-4bba2a56ec83', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'middle_name', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'middleName', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('8e7dcbbc-b4a5-4878-bf55-d9def8ac5251', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('90a17f10-a4d7-447d-83ae-bcbc0e9f556c', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('90a17f10-a4d7-447d-83ae-bcbc0e9f556c', 'realm_access.roles', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('90a17f10-a4d7-447d-83ae-bcbc0e9f556c', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('90a17f10-a4d7-447d-83ae-bcbc0e9f556c', 'true', 'multivalued');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('90a17f10-a4d7-447d-83ae-bcbc0e9f556c', 'foo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'country', 'user.attribute.country');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'formatted', 'user.attribute.formatted');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'locality', 'user.attribute.locality');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'postal_code', 'user.attribute.postal_code');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'region', 'user.attribute.region');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'street', 'user.attribute.street');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('94e1879d-b49e-4178-96e0-bf8d7f32c160', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'upn', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'username', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('959521bc-5ffd-465b-95f2-5b0c20d1909c', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'locale', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'locale', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9cfca9ee-493d-4b5e-8170-2d364149de59', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'profile', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'profile', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('9eec621f-4b88-4e89-a2cc-e8626687e263', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'email_verified', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'boolean', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'emailVerified', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('a015eb78-073d-4410-9688-7081f043c7da', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'updated_at', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'updatedAt', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('bab76e69-42e4-490a-8178-693347768509', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'middle_name', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'middleName', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('c98c063d-eee4-41a0-9130-595afd709d1f', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'zoneinfo', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'zoneinfo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('cd9150dc-ef22-48dc-abe2-b02993bfdfb4', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'email_verified', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'boolean', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'emailVerified', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d30270dc-baa6-455a-8ff6-ddccf8a78d86', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d3b25485-4042-419d-afff-cfd63a76e229', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d3b25485-4042-419d-afff-cfd63a76e229', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('d3b25485-4042-419d-afff-cfd63a76e229', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'locale', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'locale', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dc647d9e-6490-4f97-9dae-2826bee23e6a', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'gender', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'gender', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('dd0522a9-a5c2-48a7-97a0-11660b461af4', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('ee463426-41b6-4642-bd5f-7cc6b0b85663', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('ee463426-41b6-4642-bd5f-7cc6b0b85663', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('ee463426-41b6-4642-bd5f-7cc6b0b85663', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'email', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'email', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f5b1684d-e479-4134-8578-457fa64717da', 'true', 'userinfo.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'groups', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'true', 'multivalued');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('f930fbc1-169d-4ab4-a37a-1d749d4c3795', 'foo', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'true', 'access.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'nickname', 'claim.name');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'true', 'id.token.claim');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'String', 'jsonType.label');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'nickname', 'user.attribute');
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('fbf53bbd-1ad0-4bf8-8030-50f81696d8ee', 'true', 'userinfo.token.claim');

-- ----------------------------
-- Table structure for REALM
-- ----------------------------
DROP TABLE IF EXISTS `REALM`;
CREATE TABLE `REALM`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ACCESS_CODE_LIFESPAN` int(11) NULL DEFAULT NULL,
  `USER_ACTION_LIFESPAN` int(11) NULL DEFAULT NULL,
  `ACCESS_TOKEN_LIFESPAN` int(11) NULL DEFAULT NULL,
  `ACCOUNT_THEME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ADMIN_THEME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `EMAIL_THEME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EVENTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EVENTS_EXPIRATION` bigint(20) NULL DEFAULT NULL,
  `LOGIN_THEME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NOT_BEFORE` int(11) NULL DEFAULT NULL,
  `PASSWORD_POLICY` varchar(2550) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REGISTRATION_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `REMEMBER_ME` bit(1) NOT NULL DEFAULT b'0',
  `RESET_PASSWORD_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `SOCIAL` bit(1) NOT NULL DEFAULT b'0',
  `SSL_REQUIRED` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `SSO_IDLE_TIMEOUT` int(11) NULL DEFAULT NULL,
  `SSO_MAX_LIFESPAN` int(11) NULL DEFAULT NULL,
  `UPDATE_PROFILE_ON_SOC_LOGIN` bit(1) NOT NULL DEFAULT b'0',
  `VERIFY_EMAIL` bit(1) NOT NULL DEFAULT b'0',
  `MASTER_ADMIN_CLIENT` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LOGIN_LIFESPAN` int(11) NULL DEFAULT NULL,
  `INTERNATIONALIZATION_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DEFAULT_LOCALE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REG_EMAIL_AS_USERNAME` bit(1) NOT NULL DEFAULT b'0',
  `ADMIN_EVENTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `ADMIN_EVENTS_DETAILS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EDIT_USERNAME_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `OTP_POLICY_COUNTER` int(11) NULL DEFAULT 0,
  `OTP_POLICY_WINDOW` int(11) NULL DEFAULT 1,
  `OTP_POLICY_PERIOD` int(11) NULL DEFAULT 30,
  `OTP_POLICY_DIGITS` int(11) NULL DEFAULT 6,
  `OTP_POLICY_ALG` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'HmacSHA1',
  `OTP_POLICY_TYPE` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'totp',
  `BROWSER_FLOW` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REGISTRATION_FLOW` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DIRECT_GRANT_FLOW` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESET_CREDENTIALS_FLOW` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CLIENT_AUTH_FLOW` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `OFFLINE_SESSION_IDLE_TIMEOUT` int(11) NULL DEFAULT 0,
  `REVOKE_REFRESH_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  `ACCESS_TOKEN_LIFE_IMPLICIT` int(11) NULL DEFAULT 0,
  `LOGIN_WITH_EMAIL_ALLOWED` bit(1) NOT NULL DEFAULT b'1',
  `DUPLICATE_EMAILS_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `DOCKER_AUTH_FLOW` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REFRESH_TOKEN_MAX_REUSE` int(11) NULL DEFAULT 0,
  `ALLOW_USER_MANAGED_ACCESS` bit(1) NOT NULL DEFAULT b'0',
  `SSO_MAX_LIFESPAN_REMEMBER_ME` int(11) NOT NULL,
  `SSO_IDLE_TIMEOUT_REMEMBER_ME` int(11) NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_ORVSDMLA56612EAEFIQ6WL5OI`(`NAME`) USING BTREE,
  INDEX `IDX_REALM_MASTER_ADM_CLI`(`MASTER_ADMIN_CLIENT`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM
-- ----------------------------
INSERT INTO `REALM` VALUES ('baeldung', 60, 300, 300, NULL, NULL, NULL, b'1', b'0', 0, NULL, 'baeldung', 0, NULL, b'0', b'0', b'0', b'0', 'EXTERNAL', 1800, 36000, b'0', b'0', 'ac3c0b02-d013-4345-83f7-dbb2a0550ce6', 1800, b'0', NULL, b'0', b'0', b'0', b'0', 0, 1, 30, 6, 'HmacSHA1', 'totp', '3813102c-4c8b-491f-a5be-ba84a546ec16', '4dac5729-d980-458f-8b50-9662c475f229', '2d485fd1-d9d4-4663-b2e0-ba3fb853c1f9', 'bdd3e09a-6ea7-46ba-b6be-1f4b54b3a212', 'bbb11fa8-da51-4946-9f7d-853f56abba2a', 2592000, b'0', 900, b'1', b'0', '03120017-9f11-406e-a0a9-835b476c161a', 0, b'0', 0, 0);
INSERT INTO `REALM` VALUES ('master', 60, 300, 60, NULL, NULL, NULL, b'1', b'0', 0, NULL, 'master', 0, NULL, b'0', b'0', b'0', b'0', 'EXTERNAL', 1800, 36000, b'0', b'0', 'b45a3a06-bcb8-4ee0-bc0c-012fb93817fc', 1800, b'0', NULL, b'0', b'0', b'0', b'0', 0, 1, 30, 6, 'HmacSHA1', 'totp', 'b3414c84-e337-4c2e-9074-90c7eda4d9eb', '5a8cbb8b-aeaf-4ca2-802a-daf5fe6f23a9', '6164789f-eab7-466c-ac16-c6647cc93b39', '07ec271f-f933-4326-91b1-210e08b8bb34', '9173f301-5ebe-46bb-a98e-a2c46c254b83', 2592000, b'0', 900, b'1', b'0', 'aa7f7f22-29b9-4dcf-ae1b-be2c65f2d482', 0, b'0', 0, 0);

-- ----------------------------
-- Table structure for REALM_ATTRIBUTE
-- ----------------------------
DROP TABLE IF EXISTS `REALM_ATTRIBUTE`;
CREATE TABLE `REALM_ATTRIBUTE`  (
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`NAME`, `REALM_ID`) USING BTREE,
  INDEX `IDX_REALM_ATTR_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_8SHXD6L3E9ATQUKACXGPFFPTW` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_ATTRIBUTE
-- ----------------------------
INSERT INTO `REALM_ATTRIBUTE` VALUES ('actionTokenGeneratedByAdminLifespan', '43200', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('actionTokenGeneratedByUserLifespan', '300', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('bruteForceProtected', 'false', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('bruteForceProtected', 'false', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('displayName', 'Keycloak', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('displayNameHtml', '<div class=\"kc-logo-text\"><span>Keycloak</span></div>', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('failureFactor', '30', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('failureFactor', '30', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('maxDeltaTimeSeconds', '43200', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('maxDeltaTimeSeconds', '43200', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('maxFailureWaitSeconds', '900', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('maxFailureWaitSeconds', '900', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('minimumQuickLoginWaitSeconds', '60', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('minimumQuickLoginWaitSeconds', '60', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('offlineSessionMaxLifespan', '5184000', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('offlineSessionMaxLifespan', '5184000', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('offlineSessionMaxLifespanEnabled', 'false', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('offlineSessionMaxLifespanEnabled', 'false', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('permanentLockout', 'false', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('permanentLockout', 'false', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('quickLoginCheckMilliSeconds', '1000', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('quickLoginCheckMilliSeconds', '1000', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('waitIncrementSeconds', '60', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('waitIncrementSeconds', '60', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyAttestationConveyancePreference', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyAttestationConveyancePreferencePasswordless', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyAuthenticatorAttachment', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyAuthenticatorAttachmentPasswordless', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyAvoidSameAuthenticatorRegister', 'false', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless', 'false', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyCreateTimeout', '0', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyCreateTimeoutPasswordless', '0', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyRequireResidentKey', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyRequireResidentKeyPasswordless', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyRpEntityName', 'keycloak', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyRpEntityNamePasswordless', 'keycloak', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyRpId', '', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyRpIdPasswordless', '', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicySignatureAlgorithms', 'ES256', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicySignatureAlgorithmsPasswordless', 'ES256', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyUserVerificationRequirement', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('webAuthnPolicyUserVerificationRequirementPasswordless', 'not specified', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.contentSecurityPolicy', 'frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.contentSecurityPolicy', 'frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.contentSecurityPolicyReportOnly', '', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.contentSecurityPolicyReportOnly', '', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.strictTransportSecurity', 'max-age=31536000; includeSubDomains', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.strictTransportSecurity', 'max-age=31536000; includeSubDomains', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xContentTypeOptions', 'nosniff', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xContentTypeOptions', 'nosniff', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xFrameOptions', 'SAMEORIGIN', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xFrameOptions', 'SAMEORIGIN', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xRobotsTag', 'none', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xRobotsTag', 'none', 'master');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xXSSProtection', '1; mode=block', 'baeldung');
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.xXSSProtection', '1; mode=block', 'master');

-- ----------------------------
-- Table structure for REALM_DEFAULT_GROUPS
-- ----------------------------
DROP TABLE IF EXISTS `REALM_DEFAULT_GROUPS`;
CREATE TABLE `REALM_DEFAULT_GROUPS`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `GROUP_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `GROUP_ID`) USING BTREE,
  UNIQUE INDEX `CON_GROUP_ID_DEF_GROUPS`(`GROUP_ID`) USING BTREE,
  INDEX `IDX_REALM_DEF_GRP_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_DEF_GROUPS_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_DEF_GROUPS_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_DEFAULT_GROUPS
-- ----------------------------

-- ----------------------------
-- Table structure for REALM_DEFAULT_ROLES
-- ----------------------------
DROP TABLE IF EXISTS `REALM_DEFAULT_ROLES`;
CREATE TABLE `REALM_DEFAULT_ROLES`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `ROLE_ID`) USING BTREE,
  UNIQUE INDEX `UK_H4WPD7W4HSOOLNI3H0SW7BTJE`(`ROLE_ID`) USING BTREE,
  INDEX `IDX_REALM_DEF_ROLES_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_EVUDB1PPW84OXFAX2DRS03ICC` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_H4WPD7W4HSOOLNI3H0SW7BTJE` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_DEFAULT_ROLES
-- ----------------------------
INSERT INTO `REALM_DEFAULT_ROLES` VALUES ('baeldung', '0dd6a8c7-d669-4941-9ea1-521980e9c53f');
INSERT INTO `REALM_DEFAULT_ROLES` VALUES ('master', '3ad25249-37a5-45a9-b078-c6564a72cd96');
INSERT INTO `REALM_DEFAULT_ROLES` VALUES ('baeldung', '3b6109f5-6e5a-4578-83c3-791ec3e2bf9e');
INSERT INTO `REALM_DEFAULT_ROLES` VALUES ('master', 'a2ec3e99-c78c-44f5-98d7-75c3a26a68cc');

-- ----------------------------
-- Table structure for REALM_ENABLED_EVENT_TYPES
-- ----------------------------
DROP TABLE IF EXISTS `REALM_ENABLED_EVENT_TYPES`;
CREATE TABLE `REALM_ENABLED_EVENT_TYPES`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `VALUE`) USING BTREE,
  INDEX `IDX_REALM_EVT_TYPES_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_H846O4H0W8EPX5NWEDRF5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_ENABLED_EVENT_TYPES
-- ----------------------------

-- ----------------------------
-- Table structure for REALM_EVENTS_LISTENERS
-- ----------------------------
DROP TABLE IF EXISTS `REALM_EVENTS_LISTENERS`;
CREATE TABLE `REALM_EVENTS_LISTENERS`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `VALUE`) USING BTREE,
  INDEX `IDX_REALM_EVT_LIST_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_H846O4H0W8EPX5NXEV9F5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_EVENTS_LISTENERS
-- ----------------------------
INSERT INTO `REALM_EVENTS_LISTENERS` VALUES ('baeldung', 'jboss-logging');
INSERT INTO `REALM_EVENTS_LISTENERS` VALUES ('master', 'jboss-logging');

-- ----------------------------
-- Table structure for REALM_REQUIRED_CREDENTIAL
-- ----------------------------
DROP TABLE IF EXISTS `REALM_REQUIRED_CREDENTIAL`;
CREATE TABLE `REALM_REQUIRED_CREDENTIAL`  (
  `TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FORM_LABEL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `INPUT` bit(1) NOT NULL DEFAULT b'0',
  `SECRET` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `TYPE`) USING BTREE,
  CONSTRAINT `FK_5HG65LYBEVAVKQFKI3KPONH9V` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_REQUIRED_CREDENTIAL
-- ----------------------------
INSERT INTO `REALM_REQUIRED_CREDENTIAL` VALUES ('password', 'password', b'1', b'1', 'baeldung');
INSERT INTO `REALM_REQUIRED_CREDENTIAL` VALUES ('password', 'password', b'1', b'1', 'master');

-- ----------------------------
-- Table structure for REALM_SMTP_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `REALM_SMTP_CONFIG`;
CREATE TABLE `REALM_SMTP_CONFIG`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK_70EJ8XDXGXD0B9HH6180IRR0O` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_SMTP_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for REALM_SUPPORTED_LOCALES
-- ----------------------------
DROP TABLE IF EXISTS `REALM_SUPPORTED_LOCALES`;
CREATE TABLE `REALM_SUPPORTED_LOCALES`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`, `VALUE`) USING BTREE,
  INDEX `IDX_REALM_SUPP_LOCAL_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_SUPPORTED_LOCALES_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REALM_SUPPORTED_LOCALES
-- ----------------------------

-- ----------------------------
-- Table structure for REDIRECT_URIS
-- ----------------------------
DROP TABLE IF EXISTS `REDIRECT_URIS`;
CREATE TABLE `REDIRECT_URIS`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `VALUE`) USING BTREE,
  INDEX `IDX_REDIR_URI_CLIENT`(`CLIENT_ID`) USING BTREE,
  CONSTRAINT `FK_1BURS8PB4OUJ97H5WUPPAHV9F` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REDIRECT_URIS
-- ----------------------------
INSERT INTO `REDIRECT_URIS` VALUES ('12eebf0b-a3eb-49f8-9ecf-173cf8a00145', '/realms/baeldung/account/*');
INSERT INTO `REDIRECT_URIS` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '/realms/baeldung/account/*');
INSERT INTO `REDIRECT_URIS` VALUES ('5a7bec73-8335-42b1-a91f-18c84f7c9e85', '/realms/master/account/*');
INSERT INTO `REDIRECT_URIS` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', '/realms/master/account/*');
INSERT INTO `REDIRECT_URIS` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '/admin/baeldung/console/*');
INSERT INTO `REDIRECT_URIS` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '/admin/master/console/*');
INSERT INTO `REDIRECT_URIS` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'http://localhost:8082/new-client/login/oauth2/code/custom');
INSERT INTO `REDIRECT_URIS` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'http://localhost:8089/');
INSERT INTO `REDIRECT_URIS` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', 'http://localhost:8089/auth/redirect/');

-- ----------------------------
-- Table structure for REQUIRED_ACTION_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `REQUIRED_ACTION_CONFIG`;
CREATE TABLE `REQUIRED_ACTION_CONFIG`  (
  `REQUIRED_ACTION_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`REQUIRED_ACTION_ID`, `NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REQUIRED_ACTION_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for REQUIRED_ACTION_PROVIDER
-- ----------------------------
DROP TABLE IF EXISTS `REQUIRED_ACTION_PROVIDER`;
CREATE TABLE `REQUIRED_ACTION_PROVIDER`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DEFAULT_ACTION` bit(1) NOT NULL DEFAULT b'0',
  `PROVIDER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PRIORITY` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_REQ_ACT_PROV_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_REQ_ACT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of REQUIRED_ACTION_PROVIDER
-- ----------------------------
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('052f0db6-afa1-4d87-b9d6-080e43e7d138', 'UPDATE_PROFILE', 'Update Profile', 'master', b'1', b'0', 'UPDATE_PROFILE', 40);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('0da54b81-35df-4f88-aa3a-02604125dc28', 'CONFIGURE_TOTP', 'Configure OTP', 'baeldung', b'1', b'0', 'CONFIGURE_TOTP', 10);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('195f9718-3a8a-4dd7-ba45-bf30d20bea06', 'VERIFY_EMAIL', 'Verify Email', 'baeldung', b'1', b'0', 'VERIFY_EMAIL', 50);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('1fdfc302-32e2-4e4d-8a25-7fbaa41e957d', 'UPDATE_PASSWORD', 'Update Password', 'master', b'1', b'0', 'UPDATE_PASSWORD', 30);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('32c716ec-613f-4f7c-8396-3742ec845080', 'VERIFY_EMAIL', 'Verify Email', 'master', b'1', b'0', 'VERIFY_EMAIL', 50);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('418cff7a-261b-4890-8de8-b5c4082cf63e', 'update_user_locale', 'Update User Locale', 'baeldung', b'1', b'0', 'update_user_locale', 1000);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('4a610ac8-0223-4f10-9c30-91020887b650', 'terms_and_conditions', 'Terms and Conditions', 'master', b'0', b'0', 'terms_and_conditions', 20);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('6aa3481a-bedb-47c1-9f7b-2ed56f51cfb8', 'CONFIGURE_TOTP', 'Configure OTP', 'master', b'1', b'0', 'CONFIGURE_TOTP', 10);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('78779692-f12d-4edc-a85e-b2f1f69c55b7', 'terms_and_conditions', 'Terms and Conditions', 'baeldung', b'0', b'0', 'terms_and_conditions', 20);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('b7dfae9c-809d-469e-99f1-749009ebe2d2', 'UPDATE_PROFILE', 'Update Profile', 'baeldung', b'1', b'0', 'UPDATE_PROFILE', 40);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('ca141950-910a-4f88-87f7-806622224278', 'UPDATE_PASSWORD', 'Update Password', 'baeldung', b'1', b'0', 'UPDATE_PASSWORD', 30);
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('de032ea5-eda3-401e-a63e-9e529651b9b5', 'update_user_locale', 'Update User Locale', 'master', b'1', b'0', 'update_user_locale', 1000);

-- ----------------------------
-- Table structure for RESOURCE_ATTRIBUTE
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_ATTRIBUTE`;
CREATE TABLE `RESOURCE_ATTRIBUTE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `FK_5HRM2VLF9QL5FU022KQEPOVBR`(`RESOURCE_ID`) USING BTREE,
  CONSTRAINT `FK_5HRM2VLF9QL5FU022KQEPOVBR` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_ATTRIBUTE
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_POLICY
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_POLICY`;
CREATE TABLE `RESOURCE_POLICY`  (
  `RESOURCE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `POLICY_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`, `POLICY_ID`) USING BTREE,
  INDEX `IDX_RES_POLICY_POLICY`(`POLICY_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRPOS53XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRPP213XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_POLICY
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_SCOPE
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_SCOPE`;
CREATE TABLE `RESOURCE_SCOPE`  (
  `RESOURCE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`, `SCOPE_ID`) USING BTREE,
  INDEX `IDX_RES_SCOPE_SCOPE`(`SCOPE_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRPOS13XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRPS213XCX4WNKOG82SSRFY` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_SCOPE
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_SERVER
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_SERVER`;
CREATE TABLE `RESOURCE_SERVER`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ALLOW_RS_REMOTE_MGMT` bit(1) NOT NULL DEFAULT b'0',
  `POLICY_ENFORCE_MODE` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DECISION_STRATEGY` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_SERVER
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_SERVER_PERM_TICKET
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_SERVER_PERM_TICKET`;
CREATE TABLE `RESOURCE_SERVER_PERM_TICKET`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `OWNER` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REQUESTER` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint(20) NOT NULL,
  `GRANTED_TIMESTAMP` bigint(20) NULL DEFAULT NULL,
  `RESOURCE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `POLICY_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_FRSR6T700S9V50BU18WS5PMT`(`OWNER`, `REQUESTER`, `RESOURCE_SERVER_ID`, `RESOURCE_ID`, `SCOPE_ID`) USING BTREE,
  INDEX `FK_FRSRHO213XCX4WNKOG82SSPMT`(`RESOURCE_SERVER_ID`) USING BTREE,
  INDEX `FK_FRSRHO213XCX4WNKOG83SSPMT`(`RESOURCE_ID`) USING BTREE,
  INDEX `FK_FRSRHO213XCX4WNKOG84SSPMT`(`SCOPE_ID`) USING BTREE,
  INDEX `FK_FRSRPO2128CX4WNKOG82SSRFY`(`POLICY_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG82SSPMT` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG83SSPMT` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG84SSPMT` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRPO2128CX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_SERVER_PERM_TICKET
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_SERVER_POLICY
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_SERVER_POLICY`;
CREATE TABLE `RESOURCE_SERVER_POLICY`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DECISION_STRATEGY` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LOGIC` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `OWNER` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_FRSRPT700S9V50BU18WS5HA6`(`NAME`, `RESOURCE_SERVER_ID`) USING BTREE,
  INDEX `IDX_RES_SERV_POL_RES_SERV`(`RESOURCE_SERVER_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRPO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_SERVER_POLICY
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_SERVER_RESOURCE
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_SERVER_RESOURCE`;
CREATE TABLE `RESOURCE_SERVER_RESOURCE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ICON_URI` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `OWNER` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `OWNER_MANAGED_ACCESS` bit(1) NOT NULL DEFAULT b'0',
  `DISPLAY_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_FRSR6T700S9V50BU18WS5HA6`(`NAME`, `OWNER`, `RESOURCE_SERVER_ID`) USING BTREE,
  INDEX `IDX_RES_SRV_RES_RES_SRV`(`RESOURCE_SERVER_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_SERVER_RESOURCE
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_SERVER_SCOPE
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_SERVER_SCOPE`;
CREATE TABLE `RESOURCE_SERVER_SCOPE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ICON_URI` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_FRSRST700S9V50BU18WS5HA6`(`NAME`, `RESOURCE_SERVER_ID`) USING BTREE,
  INDEX `IDX_RES_SRV_SCOPE_RES_SRV`(`RESOURCE_SERVER_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRSO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_SERVER_SCOPE
-- ----------------------------

-- ----------------------------
-- Table structure for RESOURCE_URIS
-- ----------------------------
DROP TABLE IF EXISTS `RESOURCE_URIS`;
CREATE TABLE `RESOURCE_URIS`  (
  `RESOURCE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`, `VALUE`) USING BTREE,
  CONSTRAINT `FK_RESOURCE_SERVER_URIS` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of RESOURCE_URIS
-- ----------------------------

-- ----------------------------
-- Table structure for ROLE_ATTRIBUTE
-- ----------------------------
DROP TABLE IF EXISTS `ROLE_ATTRIBUTE`;
CREATE TABLE `ROLE_ATTRIBUTE`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_ROLE_ATTRIBUTE`(`ROLE_ID`) USING BTREE,
  CONSTRAINT `FK_ROLE_ATTRIBUTE_ID` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ROLE_ATTRIBUTE
-- ----------------------------

-- ----------------------------
-- Table structure for SCOPE_MAPPING
-- ----------------------------
DROP TABLE IF EXISTS `SCOPE_MAPPING`;
CREATE TABLE `SCOPE_MAPPING`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `ROLE_ID`) USING BTREE,
  INDEX `IDX_SCOPE_MAPPING_ROLE`(`ROLE_ID`) USING BTREE,
  CONSTRAINT `FK_OUSE064PLMLR732LXJCN1Q5F1` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_P3RH9GRKU11KQFRS4FLTT7RNQ` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of SCOPE_MAPPING
-- ----------------------------
INSERT INTO `SCOPE_MAPPING` VALUES ('578fe0dc-91f8-474f-a447-a20a9564d890', '8daa8096-d14e-4d1c-ad1f-83f822016aa1');
INSERT INTO `SCOPE_MAPPING` VALUES ('7c986895-caa4-40ef-b936-0e2bfddf200a', 'd3cad871-4b66-4016-b662-72446741e63d');

-- ----------------------------
-- Table structure for SCOPE_POLICY
-- ----------------------------
DROP TABLE IF EXISTS `SCOPE_POLICY`;
CREATE TABLE `SCOPE_POLICY`  (
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `POLICY_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`, `POLICY_ID`) USING BTREE,
  INDEX `IDX_SCOPE_POLICY_POLICY`(`POLICY_ID`) USING BTREE,
  CONSTRAINT `FK_FRSRASP13XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FRSRPASS3XCX4WNKOG82SSRFY` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of SCOPE_POLICY
-- ----------------------------

-- ----------------------------
-- Table structure for USER_ATTRIBUTE
-- ----------------------------
DROP TABLE IF EXISTS `USER_ATTRIBUTE`;
CREATE TABLE `USER_ATTRIBUTE`  (
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_USER_ATTRIBUTE`(`USER_ID`) USING BTREE,
  CONSTRAINT `FK_5HRM2VLF9QL5FU043KQEPOVBR` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_ATTRIBUTE
-- ----------------------------

-- ----------------------------
-- Table structure for USER_CONSENT
-- ----------------------------
DROP TABLE IF EXISTS `USER_CONSENT`;
CREATE TABLE `USER_CONSENT`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CREATED_DATE` bigint(20) NULL DEFAULT NULL,
  `LAST_UPDATED_DATE` bigint(20) NULL DEFAULT NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `EXTERNAL_CLIENT_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_JKUWUVD56ONTGSUHOGM8UEWRT`(`CLIENT_ID`, `CLIENT_STORAGE_PROVIDER`, `EXTERNAL_CLIENT_ID`, `USER_ID`) USING BTREE,
  INDEX `IDX_USER_CONSENT`(`USER_ID`) USING BTREE,
  CONSTRAINT `FK_GRNTCSNT_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_CONSENT
-- ----------------------------

-- ----------------------------
-- Table structure for USER_CONSENT_CLIENT_SCOPE
-- ----------------------------
DROP TABLE IF EXISTS `USER_CONSENT_CLIENT_SCOPE`;
CREATE TABLE `USER_CONSENT_CLIENT_SCOPE`  (
  `USER_CONSENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`USER_CONSENT_ID`, `SCOPE_ID`) USING BTREE,
  INDEX `IDX_USCONSENT_CLSCOPE`(`USER_CONSENT_ID`) USING BTREE,
  CONSTRAINT `FK_GRNTCSNT_CLSC_USC` FOREIGN KEY (`USER_CONSENT_ID`) REFERENCES `USER_CONSENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_CONSENT_CLIENT_SCOPE
-- ----------------------------

-- ----------------------------
-- Table structure for USER_ENTITY
-- ----------------------------
DROP TABLE IF EXISTS `USER_ENTITY`;
CREATE TABLE `USER_ENTITY`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `EMAIL` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `EMAIL_CONSTRAINT` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `EMAIL_VERIFIED` bit(1) NOT NULL DEFAULT b'0',
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `FEDERATION_LINK` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `FIRST_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `LAST_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USERNAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint(20) NULL DEFAULT NULL,
  `SERVICE_ACCOUNT_CLIENT_LINK` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NOT_BEFORE` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UK_DYKN684SL8UP1CRFEI6ECKHD7`(`REALM_ID`, `EMAIL_CONSTRAINT`) USING BTREE,
  UNIQUE INDEX `UK_RU8TT6T700S9V50BU18WS5HA6`(`REALM_ID`, `USERNAME`) USING BTREE,
  INDEX `IDX_USER_EMAIL`(`EMAIL`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_ENTITY
-- ----------------------------
INSERT INTO `USER_ENTITY` VALUES ('22a4d9fe-194c-4c6e-841a-8a55b402459f', NULL, '51dbcb38-da3e-4397-81df-bbcfa354cac9', b'0', b'1', NULL, NULL, NULL, 'baeldung', 'mike@other.com', 1580237252522, NULL, 0);
INSERT INTO `USER_ENTITY` VALUES ('42f3d5af-ed66-40d1-8b32-ae35ef9d619e', NULL, 'cfc54663-9364-4c2b-93b9-b3232175d7d4', b'0', b'1', NULL, NULL, NULL, 'master', 'admin', 1607909907121, NULL, 0);
INSERT INTO `USER_ENTITY` VALUES ('a5461470-33eb-4b2d-82d4-b0484e96ad7f', NULL, '0f2a5c8a-a44e-49b9-a092-6d8374661cd0', b'0', b'1', NULL, NULL, NULL, 'baeldung', 'john@test.com', 1574174706812, NULL, 0);

-- ----------------------------
-- Table structure for USER_FEDERATION_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `USER_FEDERATION_CONFIG`;
CREATE TABLE `USER_FEDERATION_CONFIG`  (
  `USER_FEDERATION_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_PROVIDER_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK_T13HPU1J94R2EBPEKR39X5EU5` FOREIGN KEY (`USER_FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_FEDERATION_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for USER_FEDERATION_MAPPER
-- ----------------------------
DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER`;
CREATE TABLE `USER_FEDERATION_MAPPER`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FEDERATION_PROVIDER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FEDERATION_MAPPER_TYPE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_USR_FED_MAP_FED_PRV`(`FEDERATION_PROVIDER_ID`) USING BTREE,
  INDEX `IDX_USR_FED_MAP_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_FEDMAPPERPM_FEDPRV` FOREIGN KEY (`FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_FEDMAPPERPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_FEDERATION_MAPPER
-- ----------------------------

-- ----------------------------
-- Table structure for USER_FEDERATION_MAPPER_CONFIG
-- ----------------------------
DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER_CONFIG`;
CREATE TABLE `USER_FEDERATION_MAPPER_CONFIG`  (
  `USER_FEDERATION_MAPPER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_MAPPER_ID`, `NAME`) USING BTREE,
  CONSTRAINT `FK_FEDMAPPER_CFG` FOREIGN KEY (`USER_FEDERATION_MAPPER_ID`) REFERENCES `USER_FEDERATION_MAPPER` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_FEDERATION_MAPPER_CONFIG
-- ----------------------------

-- ----------------------------
-- Table structure for USER_FEDERATION_PROVIDER
-- ----------------------------
DROP TABLE IF EXISTS `USER_FEDERATION_PROVIDER`;
CREATE TABLE `USER_FEDERATION_PROVIDER`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CHANGED_SYNC_PERIOD` int(11) NULL DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `FULL_SYNC_PERIOD` int(11) NULL DEFAULT NULL,
  `LAST_SYNC` int(11) NULL DEFAULT NULL,
  `PRIORITY` int(11) NULL DEFAULT NULL,
  `PROVIDER_NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `IDX_USR_FED_PRV_REALM`(`REALM_ID`) USING BTREE,
  CONSTRAINT `FK_1FJ32F6PTOLW2QY60CD8N01E8` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_FEDERATION_PROVIDER
-- ----------------------------

-- ----------------------------
-- Table structure for USER_GROUP_MEMBERSHIP
-- ----------------------------
DROP TABLE IF EXISTS `USER_GROUP_MEMBERSHIP`;
CREATE TABLE `USER_GROUP_MEMBERSHIP`  (
  `GROUP_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`GROUP_ID`, `USER_ID`) USING BTREE,
  INDEX `IDX_USER_GROUP_MAPPING`(`USER_ID`) USING BTREE,
  CONSTRAINT `FK_USER_GROUP_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_GROUP_MEMBERSHIP
-- ----------------------------

-- ----------------------------
-- Table structure for USER_REQUIRED_ACTION
-- ----------------------------
DROP TABLE IF EXISTS `USER_REQUIRED_ACTION`;
CREATE TABLE `USER_REQUIRED_ACTION`  (
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `REQUIRED_ACTION` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT ' ',
  PRIMARY KEY (`REQUIRED_ACTION`, `USER_ID`) USING BTREE,
  INDEX `IDX_USER_REQACTIONS`(`USER_ID`) USING BTREE,
  CONSTRAINT `FK_6QJ3W1JW9CVAFHE19BWSIUVMD` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_REQUIRED_ACTION
-- ----------------------------

-- ----------------------------
-- Table structure for USER_ROLE_MAPPING
-- ----------------------------
DROP TABLE IF EXISTS `USER_ROLE_MAPPING`;
CREATE TABLE `USER_ROLE_MAPPING`  (
  `ROLE_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USER_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`ROLE_ID`, `USER_ID`) USING BTREE,
  INDEX `IDX_USER_ROLE_MAPPING`(`USER_ID`) USING BTREE,
  CONSTRAINT `FK_C4FQV34P1MBYLLOXANG7B1Q3L` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_ROLE_MAPPING
-- ----------------------------
INSERT INTO `USER_ROLE_MAPPING` VALUES ('0dd6a8c7-d669-4941-9ea1-521980e9c53f', '22a4d9fe-194c-4c6e-841a-8a55b402459f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('3b6109f5-6e5a-4578-83c3-791ec3e2bf9e', '22a4d9fe-194c-4c6e-841a-8a55b402459f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('8daa8096-d14e-4d1c-ad1f-83f822016aa1', '22a4d9fe-194c-4c6e-841a-8a55b402459f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('aed18201-2433-4998-8fa3-0979b0b31c10', '22a4d9fe-194c-4c6e-841a-8a55b402459f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('3ad25249-37a5-45a9-b078-c6564a72cd96', '42f3d5af-ed66-40d1-8b32-ae35ef9d619e');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('a2ec3e99-c78c-44f5-98d7-75c3a26a68cc', '42f3d5af-ed66-40d1-8b32-ae35ef9d619e');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('abce3a0d-db23-4515-8d07-0901b182efc6', '42f3d5af-ed66-40d1-8b32-ae35ef9d619e');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('cfb69f93-bbe2-48c2-b903-5cb16d1abf5c', '42f3d5af-ed66-40d1-8b32-ae35ef9d619e');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('d3cad871-4b66-4016-b662-72446741e63d', '42f3d5af-ed66-40d1-8b32-ae35ef9d619e');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('0dd6a8c7-d669-4941-9ea1-521980e9c53f', 'a5461470-33eb-4b2d-82d4-b0484e96ad7f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('3b6109f5-6e5a-4578-83c3-791ec3e2bf9e', 'a5461470-33eb-4b2d-82d4-b0484e96ad7f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('8daa8096-d14e-4d1c-ad1f-83f822016aa1', 'a5461470-33eb-4b2d-82d4-b0484e96ad7f');
INSERT INTO `USER_ROLE_MAPPING` VALUES ('aed18201-2433-4998-8fa3-0979b0b31c10', 'a5461470-33eb-4b2d-82d4-b0484e96ad7f');

-- ----------------------------
-- Table structure for USER_SESSION
-- ----------------------------
DROP TABLE IF EXISTS `USER_SESSION`;
CREATE TABLE `USER_SESSION`  (
  `ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `AUTH_METHOD` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `IP_ADDRESS` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LAST_SESSION_REFRESH` int(11) NULL DEFAULT NULL,
  `LOGIN_USERNAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `REMEMBER_ME` bit(1) NOT NULL DEFAULT b'0',
  `STARTED` int(11) NULL DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `USER_SESSION_STATE` int(11) NULL DEFAULT NULL,
  `BROKER_SESSION_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `BROKER_USER_ID` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_SESSION
-- ----------------------------

-- ----------------------------
-- Table structure for USER_SESSION_NOTE
-- ----------------------------
DROP TABLE IF EXISTS `USER_SESSION_NOTE`;
CREATE TABLE `USER_SESSION_NOTE`  (
  `USER_SESSION` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(2048) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`USER_SESSION`, `NAME`) USING BTREE,
  CONSTRAINT `FK5EDFB00FF51D3472` FOREIGN KEY (`USER_SESSION`) REFERENCES `USER_SESSION` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USER_SESSION_NOTE
-- ----------------------------

-- ----------------------------
-- Table structure for USERNAME_LOGIN_FAILURE
-- ----------------------------
DROP TABLE IF EXISTS `USERNAME_LOGIN_FAILURE`;
CREATE TABLE `USERNAME_LOGIN_FAILURE`  (
  `REALM_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `USERNAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `FAILED_LOGIN_NOT_BEFORE` int(11) NULL DEFAULT NULL,
  `LAST_FAILURE` bigint(20) NULL DEFAULT NULL,
  `LAST_IP_FAILURE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `NUM_FAILURES` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`REALM_ID`, `USERNAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of USERNAME_LOGIN_FAILURE
-- ----------------------------

-- ----------------------------
-- Table structure for WEB_ORIGINS
-- ----------------------------
DROP TABLE IF EXISTS `WEB_ORIGINS`;
CREATE TABLE `WEB_ORIGINS`  (
  `CLIENT_ID` varchar(36) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`, `VALUE`) USING BTREE,
  INDEX `IDX_WEB_ORIG_CLIENT`(`CLIENT_ID`) USING BTREE,
  CONSTRAINT `FK_LOJPHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of WEB_ORIGINS
-- ----------------------------
INSERT INTO `WEB_ORIGINS` VALUES ('8e358d2f-b085-4243-8e6e-c175431e5eeb', '+');
INSERT INTO `WEB_ORIGINS` VALUES ('aaf12708-e1b3-43ea-a94c-3d4151beced2', '+');
INSERT INTO `WEB_ORIGINS` VALUES ('b88ce206-63d6-43b6-87c9-ea09d8c02f32', '+');

SET FOREIGN_KEY_CHECKS = 1;
